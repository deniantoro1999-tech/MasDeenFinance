import React, { useState, useEffect, useRef, useMemo, Component, ErrorInfo, ReactNode } from 'react';
import { 
  ShoppingCart, Settings, X, Search, Trash2, Plus, ShieldCheck, 
  Package, Wallet, Clock, Printer, Cpu, Send, Loader2, BrainCircuit, Zap,
  History, Box, Edit3, TrendingUp, TrendingDown, Terminal,
  FileText, Download, Users, CheckCircle2, WalletCards, BadgeCheck, Cloud,
  ArrowUpDown, ListFilter, MinusCircle, Receipt, ArrowRightLeft, ShoppingBag,
  PlusCircle, Share2, Info, AlertTriangle, UserPlus, ChevronDown
} from 'lucide-react';
import { 
  signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut 
} from 'firebase/auth';
import { 
  doc, setDoc, collection, onSnapshot, addDoc, getDoc, query, increment, getDocFromServer, deleteDoc 
} from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel } from 'docx';
import { saveAs } from 'file-saver';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  LineChart, Line, AreaChart, Area 
} from 'recharts';
import Markdown from 'react-markdown';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db, auth } from './firebase';

const appId = 'masdeen-finance-v16';

// Error Handling Spec for Firestore Operations
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Error Boundary Component
class ErrorBoundary extends React.Component<any, any> {
  state = { hasError: false, error: null };

  constructor(props: any) {
    super(props);
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6 text-center">
          <AlertTriangle size={48} className="text-red-500 mb-4" />
          <h1 className="text-xl font-bold mb-2">Something went wrong</h1>
          <p className="text-gray-400 text-sm mb-4 max-w-md">
            {this.state.error?.message || "An unexpected error occurred."}
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-bold"
          >
            Reload Application
          </button>
        </div>
      );
    }
    return (this as any).props.children;
  }
}

// Fungsi format angka dengan titik sebagai pemisah ribuan
const formatNumber = (num: number) => {
  return new Intl.NumberFormat('id-ID').format(Math.floor(num || 0));
};

const globalStyles = `
  @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
  .animate-shimmer { background: linear-gradient(90deg, #EAB308 0%, #FEF08A 25%, #EAB308 50%); background-size: 200% auto; color: transparent; -webkit-background-clip: text; background-clip: text; animation: shimmer 4s linear infinite; }
  .glass-panel { background: rgba(10, 10, 10, 0.85); backdrop-filter: blur(20px); border: 1px solid rgba(234, 179, 8, 0.15); }
  .compact-card { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(234, 179, 8, 0.05); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); min-height: 60px; }
  .compact-card:hover { background: rgba(234, 179, 8, 0.1); border-color: rgba(234, 179, 8, 0.4); transform: translateY(-3px); box-shadow: 0 10px 20px -10px rgba(234, 179, 8, 0.3); }
  
  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: #050505; }
  ::-webkit-scrollbar-thumb { background: rgba(234, 179, 8, 0.3); border-radius: 10px; }

  .receipt-container {
    max-width: 58mm;
    margin: 0 auto;
    padding: 5mm;
    font-family: 'Courier New', Courier, monospace;
    font-size: 9pt;
    line-height: 1.2;
    color: #000;
    background: #fff;
  }
  .receipt-header { text-align: center; margin-bottom: 5mm; }
  .receipt-divider { border-top: 1px dashed #000; margin: 3mm 0; }
  .receipt-item { display: flex; justify-content: space-between; margin-bottom: 1mm; }
  .receipt-total { font-weight: bold; font-size: 11pt; margin-top: 3mm; border-top: 1px solid #000; padding-top: 2mm; }
  .receipt-footer { text-align: center; margin-top: 5mm; font-size: 8pt; }

  @media print {
    .no-print { display: none !important; }
    .print-only { 
      display: block !important; 
      width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
    }
    
    /* Thermal Printer Optimization */
    @page {
      size: 58mm auto;
      margin: 0;
    }
    
    body {
      width: 58mm;
      margin: 0;
      padding: 0;
    }

    .print-only .receipt-container {
      width: 58mm;
      padding: 2mm;
      margin: 0;
    }
    
    /* Disable all animations and transforms which create new stacking contexts and break printing */
    * {
      transform: none !important;
      transition: none !important;
      animation: none !important;
    }

    /* Reset all containers to allow full page printing */
    body, html, #root { 
      background: white !important; 
      color: black !important; 
      padding: 0 !important; 
      margin: 0 !important; 
      height: auto !important; 
      min-height: auto !important;
      overflow: visible !important; 
      position: static !important;
    }
    
    /* Override Tailwind classes that clip print content */
    .h-screen, .min-h-screen, .overflow-hidden, .overflow-y-auto, .overflow-x-auto {
      height: auto !important;
      min-height: 0 !important;
      max-height: none !important;
      overflow: visible !important;
    }

    /* Ensure flex containers don't restrict height */
    .flex-1, .flex {
      height: auto !important;
      min-height: 0 !important;
    }

    @page { margin: 1.5cm; }
    .report-table { width: 100%; border-collapse: collapse; font-family: 'Inter', sans-serif; font-size: 9pt; margin-bottom: 20px; }
    .report-table th, .report-table td { border: 1px solid #000; padding: 6px 8px; text-align: left; }
    .report-table th { background-color: #f3f4f6 !important; -webkit-print-color-adjust: exact; }
    .official-stamp { border: 2px solid #000; padding: 6px 12px; display: inline-block; font-weight: bold; font-size: 9pt; margin-top: 10px; text-transform: uppercase; }
    .print-header { border-bottom: 3px double #000; padding-bottom: 10px; margin-bottom: 20px; text-align: center; }
    .print-summary-box { border: 1px solid #000; padding: 15px; margin-bottom: 20px; }
  }
`;

const PremiumLogo = ({ className = "w-10 h-10" }: { className?: string }) => (
  <div className={`relative flex items-center justify-center ${className}`}>
    <div className="absolute inset-0 bg-gradient-to-tr from-yellow-600/20 via-yellow-400/10 to-transparent rounded-full blur-xl animate-[spin_4s_linear_infinite]"></div>
    <div className="absolute inset-1 bg-gradient-to-b from-black to-[#0a0a0a] rounded-full border border-yellow-500/20 shadow-[inset_0_0_20px_rgba(234,179,8,0.1)]"></div>
    <svg viewBox="0 0 100 100" className="w-[60%] h-[60%] relative z-10 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]">
      <defs>
        <linearGradient id="goldPremium" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FEF08A" />
          <stop offset="30%" stopColor="#F59E0B" />
          <stop offset="70%" stopColor="#B45309" />
          <stop offset="100%" stopColor="#78350F" />
        </linearGradient>
        <linearGradient id="goldLight" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FEF08A" />
          <stop offset="50%" stopColor="#FDE047" />
          <stop offset="100%" stopColor="#FFFFFF" />
        </linearGradient>
      </defs>
      <path d="M 30 15 L 50 15 C 75 15 85 35 85 50 C 85 65 75 85 50 85 L 30 85 Z" fill="none" stroke="url(#goldPremium)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M 60 5 L 60 95 M 75 30 C 75 15 45 15 45 30 C 45 50 75 50 75 70 C 75 85 45 85 45 70" fill="none" stroke="url(#goldLight)" strokeWidth="4" strokeLinecap="round" />
    </svg>
  </div>
);

const BrandHeader = ({ storeName, developerName, officialLabel, isMobile = false }: any) => {
  if (isMobile) {
    return (
      <div className="flex justify-between items-center w-full">
        <div className="flex items-center gap-3">
          <PremiumLogo className="w-9 h-9" />
          <div className="flex flex-col">
            <h1 className="text-[11px] font-medium tracking-[0.2em] uppercase bg-gradient-to-b from-yellow-100 via-yellow-400 to-yellow-700 bg-clip-text text-transparent drop-shadow-lg">
              {storeName}
            </h1>
            <p className="text-[6px] text-yellow-500/80 uppercase tracking-[0.4em] font-bold">Premium POS</p>
          </div>
        </div>
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-1 bg-black px-2 py-1 rounded-lg border border-blue-500/20">
            <span className="text-[8px] font-bold text-white uppercase">{developerName}</span>
            <BadgeCheck size={10} className="text-blue-500" />
          </div>
          <span className="text-[5px] text-blue-400 mt-0.5 tracking-wider font-bold">✓ {officialLabel}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center w-full">
      <div className="flex items-center gap-3 mb-5">
        <PremiumLogo className="w-12 h-12" />
        <div className="flex flex-col items-start">
          <h1 className="text-[13px] font-medium tracking-[0.3em] uppercase bg-gradient-to-b from-yellow-100 via-yellow-400 to-yellow-700 bg-clip-text text-transparent drop-shadow-lg leading-tight">
            {storeName}
          </h1>
          <div className="flex items-center gap-2 mt-1">
            <div className="h-[1px] w-4 bg-gradient-to-r from-transparent to-yellow-500/50"></div>
            <p className="text-[7px] text-yellow-500/80 uppercase tracking-[0.4em] font-bold">Premium POS</p>
            <div className="h-[1px] w-4 bg-gradient-to-l from-transparent to-yellow-500/50"></div>
          </div>
        </div>
      </div>
      
      <div className="w-full flex flex-col items-center gap-1 bg-black/50 py-3 px-3 rounded-xl border border-blue-500/30 shadow-[0_0_10px_rgba(59,130,246,0.1)]">
        <span className="text-[7px] text-gray-400 uppercase tracking-widest">Dikembangkan Oleh</span>
        <div className="flex items-center gap-1">
            <span className="text-[11px] font-bold text-white uppercase tracking-widest">{developerName}</span>
            <BadgeCheck size={14} className="text-blue-500" />
        </div>
        <div className="mt-1 bg-blue-500/10 px-2 py-0.5 rounded text-[7px] font-bold text-blue-400 tracking-wider">
          ✓ {officialLabel}
        </div>
      </div>
    </div>
  );
};

function MainApp() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [activeTab, setActiveTab] = useState('pos');
  const [storeName, setStoreName] = useState('MASDEEN FINANCE');
  const [receiptHeader, setReceiptHeader] = useState('Jl. Ekonomi No. 123, Jakarta\nTelp: 0812-3456-7890');
  const [receiptFooter, setReceiptFooter] = useState('Barang yang sudah dibeli tidak dapat ditukar.\nTerima kasih atas kunjungan Anda!');
  const [receiptLogo, setReceiptLogo] = useState('');
  const [receiptColor, setReceiptColor] = useState('#000000');
  const [currency, setCurrency] = useState('IDR');
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [dailyStats, setDailyStats] = useState<any>({ 
    sales: 0, 
    transactions: 0, 
    capital: 0, 
    expenses: [],
    incomes: []
  });
  const [history, setHistory] = useState<any[]>([]);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [backupData, setBackupData] = useState<any>(null);
  const [posMode, setPosMode] = useState('BELI');
  const [aiModel, setAiModel] = useState('gemini-3-flash-preview');
  const [features, setFeatures] = useState({
    showSales: true,
    showIncome: false,
    showStockPurchase: true,
    showCustomerModule: true,
    showAIChat: true
  });
  
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  const developerName = "Deni Antoro";
  const officialLabel = "LABEL RESMI DISAHKAN";

  // Auth Lifecycle
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.error("Kesalahan Autentikasi:", err.message);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err: any) {
      console.error("Kesalahan Logout:", err.message);
    }
  };

  // Validate Connection to Firestore
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Error Sync Firestore
  useEffect(() => {
    if (!user || !isAuthReady) return;
    
    const prodPath = `artifacts/${appId}/public/data/products`;
    const prodRef = collection(db, prodPath);
    const unsubProd = onSnapshot(prodRef, (snap) => {
      setProducts(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (err) => handleFirestoreError(err, OperationType.GET, prodPath));

    const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
    const statsDocRef = doc(db, statsPath);
    const unsubStats = onSnapshot(statsDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setDailyStats({
          sales: data.sales || 0,
          transactions: data.transactions || 0,
          capital: data.capital || 0,
          expenses: data.expenses || [],
          incomes: data.incomes || []
        });
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, statsPath));

    const histPath = `artifacts/${appId}/public/data/history`;
    const histRef = collection(db, histPath);
    const unsubHist = onSnapshot(histRef, (snap) => {
      const hData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setHistory(hData.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }, (err) => handleFirestoreError(err, OperationType.GET, histPath));

    const custPath = `artifacts/${appId}/public/data/customers`;
    const custRef = collection(db, custPath);
    const unsubCust = onSnapshot(custRef, (snap) => {
      const cData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setCustomers(cData.sort((a: any, b: any) => a.name.localeCompare(b.name)));
    }, (err) => handleFirestoreError(err, OperationType.GET, custPath));

    return () => { unsubProd(); unsubStats(); unsubHist(); unsubCust(); };
  }, [user, isAuthReady]);

  const formatCurrency = (amount: number) => {
    const symbol = currency === 'IDR' ? 'Rp' : currency;
    return `${formatNumber(amount)}${symbol}`;
  };

  const handleCheckout = async (total: number, mode: string, items: any[], customer?: any) => {
    if (!user || !isAuthReady) return;
    const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
    const statsDocRef = doc(db, statsPath);
    
    try {
      if (mode === 'JUAL') {
        const saleEntry = { 
          note: `PENJUALAN${customer ? `: ${customer.name}` : ''}`.toUpperCase(), 
          amount: parseFloat(total.toString()), 
          time: new Date().toISOString(),
          customerId: customer?.id || null,
          items: items.map(i => ({ name: i.name, qty: i.qty, price: i.price }))
        };
        const newIncomes = [...(dailyStats.incomes || []), saleEntry];
        
        await setDoc(statsDocRef, {
          sales: (dailyStats.sales || 0) + total,
          transactions: (dailyStats.transactions || 0) + 1,
          incomes: newIncomes
        }, { merge: true });
      } else {
        const itemNames = items.map(i => i.name).join(', ');
        const newExpenses = [...(dailyStats.expenses || []), { 
          note: `BELI STOK: ${itemNames}`.toUpperCase(), 
          amount: parseFloat(total.toString()), 
          time: new Date().toISOString(),
          items: items.map(i => ({ name: i.name, qty: i.qty, price: i.price }))
        }];
        await setDoc(statsDocRef, { 
          expenses: newExpenses,
          transactions: (dailyStats.transactions || 0) + 1
        }, { merge: true });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, statsPath);
    }
  };

  const downloadReceiptPDF = (transaction: any) => {
    const doc = new jsPDF({
      unit: 'mm',
      format: [58, 150]
    });

    if (receiptColor) {
      const hex = receiptColor.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16) || 0;
      const g = parseInt(hex.substring(2, 4), 16) || 0;
      const b = parseInt(hex.substring(4, 6), 16) || 0;
      doc.setFillColor(r, g, b);
      doc.rect(0, 0, 58, 4, 'F');
    }

    doc.setFont("courier", "bold");
    doc.setFontSize(10);
    doc.text(storeName, 29, 10, { align: 'center' });
    
    doc.setFont("courier", "normal");
    doc.setFontSize(7);
    const headerLines = doc.splitTextToSize(receiptHeader, 50);
    doc.text(headerLines, 29, 15, { align: 'center' });

    let y = 15 + (headerLines.length * 3) + 5;
    doc.setLineDashPattern([1, 1], 0);
    doc.line(5, y, 53, y);
    y += 5;

    doc.text(`NO: #${transaction.id || 'REPRINT'}`, 5, y);
    doc.text(new Date(transaction.date || transaction.time).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' }), 53, y, { align: 'right' });
    y += 5;

    if (transaction.customer || transaction.customerId) {
      const custName = transaction.customer?.name || customers.find((c: any) => c.id === transaction.customerId)?.name || 'PELANGGAN';
      doc.text(`PELANGGAN: ${custName}`, 5, y);
      y += 4;
    }

    doc.setFont("courier", "bold");
    doc.text(`STRUK ${transaction.mode || 'PENJUALAN'}`, 29, y + 2, { align: 'center' });
    y += 8;

    doc.setFont("courier", "normal");
    const items = transaction.items || [];
    items.forEach((item: any) => {
      doc.text(item.name.substring(0, 25), 5, y);
      y += 4;
      doc.text(`${item.qty} x ${formatCurrency(item.price)}`, 10, y);
      doc.text(formatCurrency(item.price * item.qty), 53, y, { align: 'right' });
      y += 5;
    });

    doc.line(5, y, 53, y);
    y += 6;

    doc.setFontSize(10);
    doc.setFont("courier", "bold");
    doc.text("TOTAL", 5, y);
    doc.text(formatCurrency(transaction.total || transaction.amount), 53, y, { align: 'right' });
    y += 8;

    doc.setFontSize(7);
    doc.setFont("courier", "normal");
    const footerLines = doc.splitTextToSize(receiptFooter, 50);
    doc.text(footerLines, 29, y, { align: 'center' });
    y += (footerLines.length * 3) + 5;

    doc.text(`✓ ${officialLabel}`, 29, y, { align: 'center' });
    doc.text(`Powered by ${developerName}`, 29, y + 3, { align: 'center' });

    doc.save(`Nota_${transaction.id || 'Reprint'}.pdf`);
  };

  const handleResetData = async () => {
    if (!user || !isAuthReady) return;
    setIsResetting(true);
    
    try {
      // 1. Reset Daily Stats
      const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
      await setDoc(doc(db, statsPath), {
        sales: 0,
        transactions: 0,
        capital: 0,
        expenses: [],
        incomes: []
      });

      // 2. Clear Products
      for (const p of products) {
        await deleteDoc(doc(db, `artifacts/${appId}/public/data/products`, p.id));
      }

      // 3. Clear Customers
      for (const c of customers) {
        await deleteDoc(doc(db, `artifacts/${appId}/public/data/customers`, c.id));
      }

      // 4. Clear History
      for (const h of history) {
        await deleteDoc(doc(db, `artifacts/${appId}/public/data/history`, h.id));
      }

      setShowResetConfirm(false);
      setActiveTab('pos');
    } catch (err: any) {
      console.error("Gagal meriset data:", err.message);
    } finally {
      setIsResetting(false);
    }
  };

  const handleBackup = () => {
    const data = {
      appId,
      timestamp: new Date().toISOString(),
      storeName,
      receiptHeader,
      receiptFooter,
      receiptLogo,
      receiptColor,
      currency,
      products,
      customers,
      dailyStats,
      history,
      features
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    saveAs(blob, `Backup_${storeName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`);
  };

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        setBackupData(data);
        setShowRestoreConfirm(true);
      } catch (err) {
        console.error("Gagal membaca file backup:", err);
        alert("Format file backup tidak valid.");
      }
    };
    reader.readAsText(file);
    // Reset input value so same file can be selected again
    e.target.value = '';
  };

  const confirmRestore = async () => {
    if (!backupData || !user) return;
    setIsRestoring(true);
    try {
      // Restore local state
      if (backupData.storeName) setStoreName(backupData.storeName);
      if (backupData.receiptHeader) setReceiptHeader(backupData.receiptHeader);
      if (backupData.receiptFooter) setReceiptFooter(backupData.receiptFooter);
      if (backupData.receiptLogo) setReceiptLogo(backupData.receiptLogo);
      if (backupData.receiptColor) setReceiptColor(backupData.receiptColor);
      if (backupData.currency) setCurrency(backupData.currency);
      if (backupData.features) setFeatures(backupData.features);

      // Restore Firestore
      // 1. Products
      const prodPath = `artifacts/${appId}/public/data/products`;
      for (const p of backupData.products || []) {
        const { id, ...rest } = p;
        await setDoc(doc(db, prodPath, id || Math.random().toString(36).substr(2, 9)), rest);
      }
      // 2. Customers
      const custPath = `artifacts/${appId}/public/data/customers`;
      for (const c of backupData.customers || []) {
        const { id, ...rest } = c;
        await setDoc(doc(db, custPath, id || Math.random().toString(36).substr(2, 9)), rest);
      }
      // 3. History
      const histPath = `artifacts/${appId}/public/data/history`;
      for (const h of backupData.history || []) {
        const { id, ...rest } = h;
        await setDoc(doc(db, histPath, id || Math.random().toString(36).substr(2, 9)), rest);
      }
      // 4. Daily Stats
      const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
      if (backupData.dailyStats) {
        await setDoc(doc(db, statsPath), backupData.dailyStats);
      }

      setShowRestoreConfirm(false);
      setBackupData(null);
      alert("Data berhasil dipulihkan!");
    } catch (err) {
      console.error("Gagal memulihkan data:", err);
      alert("Terjadi kesalahan saat memulihkan data.");
    } finally {
      setIsRestoring(false);
    }
  };

  const addExternalFund = async (type: string, note: string, amount: string, dueDate?: string) => {
    if (!user || !isAuthReady || !note || !amount) return;
    const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
    const statsDocRef = doc(db, statsPath);
    const amountNum = parseFloat(amount);
    const entry = { 
      note: note.toUpperCase(), 
      amount: amountNum, 
      time: new Date().toISOString(),
      dueDate: dueDate || null 
    };
    
    try {
      if (type === 'EXPENSE') {
        const newExpenses = [...(dailyStats.expenses || []), entry];
        await setDoc(statsDocRef, { expenses: newExpenses }, { merge: true });
      } else if (type === 'CAPITAL') {
        await setDoc(statsDocRef, { capital: (dailyStats.capital || 0) + amountNum }, { merge: true });
      } else {
        const newIncomes = [...(dailyStats.incomes || []), entry];
        await setDoc(statsDocRef, { incomes: newIncomes }, { merge: true });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, statsPath);
    }
  };

  const closeDay = async () => {
    if (!user || !isAuthReady) return;
    const totalExpenses = (dailyStats.expenses || []).reduce((sum: number, e: any) => sum + e.amount, 0);
    const totalIncomes = (dailyStats.incomes || []).reduce((sum: number, i: any) => sum + i.amount, 0);
    const netCash = (dailyStats.capital || 0) + (dailyStats.sales || 0) + totalIncomes - totalExpenses;
    
    const histPath = `artifacts/${appId}/public/data/history`;
    const histRef = collection(db, histPath);
    try {
      await addDoc(histRef, {
        type: 'TUTUP_BUKU',
        sales: dailyStats.sales || 0,
        capital: dailyStats.capital || 0,
        expensesTotal: totalExpenses,
        incomesTotal: totalIncomes,
        netCash: netCash,
        transactions: dailyStats.transactions || 0,
        expenses: dailyStats.expenses || [],
        incomes: dailyStats.incomes || [],
        date: new Date().toISOString(),
        note: `Arsip Selesai - Kas: ${formatCurrency(netCash)}`
      });
      
      const statsPath = `artifacts/${appId}/public/data/daily_stats/current_day`;
      const statsDocRef = doc(db, statsPath);
      await setDoc(statsDocRef, { sales: 0, transactions: 0, capital: 0, expenses: [], incomes: [] });
      setActiveTab('reports');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, histPath);
    }
  };

  // Notification Logic
  useEffect(() => {
    if (!user || !isAuthReady) return;

    const checkNotifications = () => {
      const newNotifications: any[] = [];
      const now = new Date();

      // 1. Close Day Reminder (after 9 PM)
      if (now.getHours() >= 21 && dailyStats.sales > 0) {
        newNotifications.push({
          id: 'close-day',
          type: 'REMINDER',
          title: 'Waktunya Tutup Buku',
          message: 'Hari sudah malam, jangan lupa untuk menutup buku hari ini.',
          icon: Clock,
          color: 'text-yellow-500'
        });
      }

      // 2. Upcoming Expenses
      const allExpenses = [
        ...(dailyStats.expenses || []),
        ...history.slice(0, 10).flatMap(h => h.expenses || [])
      ];

      allExpenses.forEach((exp: any, idx: number) => {
        if (exp.dueDate) {
          const dueDate = new Date(exp.dueDate);
          const diffTime = dueDate.getTime() - now.getTime();
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

          if (diffDays >= 0 && diffDays <= 3) {
            newNotifications.push({
              id: `expense-${idx}-${exp.time}`,
              type: 'EXPENSE_DUE',
              title: 'Jatuh Tempo Biaya',
              message: `Biaya "${exp.note}" jatuh tempo dalam ${diffDays === 0 ? 'hari ini' : diffDays + ' hari'}.`,
              icon: AlertTriangle,
              color: 'text-red-500'
            });
          }
        }
      });

      setNotifications(newNotifications);
    };

    checkNotifications();
    const interval = setInterval(checkNotifications, 60000 * 30); // Check every 30 mins
    return () => clearInterval(interval);
  }, [user, isAuthReady, dailyStats.sales, dailyStats.expenses, history]);

  const navItems = [
    { id: 'pos', Icon: ShoppingCart, label: 'Kasir' },
    { id: 'daily', Icon: FileText, label: 'Ringkasan' },
    { id: 'customers', Icon: Users, label: 'Pelanggan', feature: 'showCustomerModule' },
    { id: 'reports', Icon: History, label: 'Arsip' },
    { id: 'ai-chat', Icon: BrainCircuit, label: 'MasdeenAI', feature: 'showAIChat' },
    { id: 'settings', Icon: Settings, label: 'Pengaturan' }
  ].filter(item => !(item as any).feature || (features as any)[(item as any).feature]);

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="text-yellow-500 animate-spin" size={48} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-12 rounded-3xl max-w-md w-full border-2 border-yellow-500/30"
        >
          <div className="w-20 h-20 bg-yellow-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-yellow-500/20">
            <Wallet className="text-yellow-500" size={40} />
          </div>
          <h1 className="text-3xl font-black text-white mb-2 tracking-tighter">MASDEEN FINANCE</h1>
          <p className="text-gray-400 mb-8 text-sm">Sistem Keuangan & POS Terpadu untuk Bisnis Anda</p>
          
          <button 
            onClick={handleLogin}
            className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-4 rounded-xl flex items-center justify-center gap-3 transition-all active:scale-95 shadow-lg shadow-yellow-500/20"
          >
            <Users size={20} />
            Masuk dengan Google
          </button>
          
          <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-center gap-4 text-gray-500">
            <ShieldCheck size={16} />
            <span className="text-xs uppercase tracking-widest font-bold">Aman & Terenkripsi</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <>
      <style>{globalStyles}</style>
      <div className="min-h-screen bg-[#020202] text-gray-200 font-sans flex flex-col md:flex-row overflow-hidden">
        
        {/* Sidebar Desktop */}
        <nav id="sidebar-desktop" className="hidden md:flex w-64 bg-[#080808] border-r border-yellow-900/20 flex-col z-50 no-print">
          <div className="p-6 border-b border-yellow-900/10 text-center">
            <BrandHeader storeName={storeName} developerName={developerName} officialLabel={officialLabel} />
          </div>
          <div className="flex-1 px-4 py-6 space-y-2">
            {navItems.map(item => (
              <button key={item.id} id={`nav-${item.id}`} onClick={() => setActiveTab(item.id)} 
                className={`w-full flex items-center space-x-3 px-4 py-3.5 rounded-xl transition-all font-bold text-xs ${activeTab === item.id ? 'bg-gradient-to-r from-yellow-500/20 to-transparent border-l-2 border-yellow-500 text-yellow-500 shadow-lg' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
                <item.Icon size={18}/> <span className="uppercase tracking-tighter">{item.label}</span>
              </button>
            ))}
          </div>

          <div className="p-4 border-t border-yellow-900/10">
            <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center border border-yellow-500/30 overflow-hidden">
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <Users size={20} className="text-yellow-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-white truncate">{user?.displayName || 'Pengguna'}</p>
                  <p className="text-[10px] text-gray-500 truncate">{user?.email}</p>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="w-full py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-500 text-[10px] font-bold uppercase tracking-widest transition-colors border border-red-500/20 flex items-center justify-center gap-2"
              >
                <X size={12} />
                Keluar Sesi
              </button>
            </div>
          </div>
        </nav>

        {/* Navigasi Mobile Bawah */}
        <nav id="nav-mobile" className="md:hidden fixed bottom-0 left-0 right-0 bg-[#080808]/90 backdrop-blur-md border-t border-yellow-900/20 flex justify-around items-center p-2 z-[100] no-print pb-safe">
          {navItems.map(item => (
            <button key={item.id} id={`nav-mobile-${item.id}`} onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center p-2 rounded-lg transition-all ${activeTab === item.id ? 'text-yellow-500 scale-110' : 'text-gray-500 opacity-60'}`}>
              <item.Icon size={20}/>
              <span className="text-[8px] font-black uppercase mt-1 tracking-tighter">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Konten Utama */}
        <main className="flex-1 flex flex-col h-screen overflow-hidden bg-[#050505] pb-16 md:pb-0">
          <header id="main-header" className="p-4 bg-[#080808] border-b border-yellow-900/10 flex justify-between items-center no-print">
             <div className="md:hidden">
               <BrandHeader storeName={storeName} developerName={developerName} officialLabel={officialLabel} isMobile={true} />
             </div>
             <div className="hidden md:block">
               <h2 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">{navItems.find(i => i.id === activeTab)?.label}</h2>
             </div>
             
             <div className="flex items-center gap-4">
               <button 
                 onClick={() => setShowNotifications(!showNotifications)}
                 className="relative w-10 h-10 rounded-xl bg-white/5 border border-white/5 flex items-center justify-center hover:bg-white/10 transition-all"
               >
                 <Zap size={18} className={notifications.length > 0 ? 'text-yellow-500 animate-pulse' : 'text-gray-500'} />
                 {notifications.length > 0 && (
                   <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[8px] font-black flex items-center justify-center text-white border-2 border-[#080808]">
                     {notifications.length}
                   </span>
                 )}
               </button>
             </div>
          </header>

          <div className="flex-1 overflow-hidden flex flex-col relative">
            {/* Notification Dropdown */}
            <AnimatePresence>
              {showNotifications && (
                <motion.div 
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.95 }}
                  className="absolute top-4 right-4 z-[200] w-80 bg-[#0a0a0a] border border-white/10 rounded-3xl shadow-2xl overflow-hidden"
                >
                  <div className="p-5 border-b border-white/5 flex justify-between items-center bg-black/50">
                    <h3 className="text-[10px] font-black text-white uppercase tracking-widest">Notifikasi</h3>
                    <button onClick={() => setShowNotifications(false)} className="text-gray-500 hover:text-white"><X size={14}/></button>
                  </div>
                  <div className="max-h-[400px] overflow-y-auto p-2 space-y-2">
                    {notifications.length === 0 ? (
                      <div className="p-10 text-center">
                        <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                          <BadgeCheck size={24} className="text-gray-700" />
                        </div>
                        <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Semua Beres!</p>
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div key={n.id} className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group">
                          <div className="flex gap-3">
                            <div className={`w-8 h-8 rounded-lg bg-black flex items-center justify-center ${n.color} border border-white/5`}>
                              <n.icon size={14} />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-[10px] font-black text-white uppercase tracking-tighter mb-1">{n.title}</h4>
                              <p className="text-[9px] text-gray-400 leading-relaxed">{n.message}</p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="flex-1 flex flex-col overflow-hidden"
              >
                {activeTab === 'pos' && (
                  <POSModule 
                    products={products} onCheckout={handleCheckout} onExternalFund={addExternalFund}
                    storeName={storeName} developer={developerName} officialLabel={officialLabel} dailyStats={dailyStats}
                    formatCurrency={formatCurrency} db={db}
                    receiptHeader={receiptHeader} receiptFooter={receiptFooter}
                    receiptLogo={receiptLogo} receiptColor={receiptColor}
                    customers={customers} setActiveTab={setActiveTab}
                    downloadReceiptPDF={downloadReceiptPDF}
                    posMode={posMode}
                    features={features}
                  />
                )}
                {activeTab === 'daily' && (
                  <DailyReportModule 
                    stats={dailyStats} 
                    history={history}
                    onCloseDay={closeDay} 
                    formatCurrency={formatCurrency} 
                    storeName={storeName} 
                    developer={developerName} 
                    officialLabel={officialLabel} 
                    downloadReceiptPDF={downloadReceiptPDF}
                    features={features}
                  />
                )}
                {activeTab === 'customers' && (
                  <CustomersModule 
                    customers={customers} 
                    history={history} 
                    dailyStats={dailyStats} 
                    formatCurrency={formatCurrency} 
                    db={db} 
                  />
                )}
                {activeTab === 'reports' && (
                  <ReportsModule history={history} formatCurrency={formatCurrency} storeName={storeName} developer={developerName} officialLabel={officialLabel} features={features} />
                )}
                {activeTab === 'ai-chat' && (
                  <AIModule 
                    developer={developerName} 
                    dailyStats={dailyStats} 
                    history={history} 
                    formatCurrency={formatCurrency}
                    aiModel={aiModel}
                    setAiModel={setAiModel}
                  />
                )}
                {activeTab === 'settings' && (
                  <SettingsModule 
                    storeName={storeName} setStoreName={setStoreName} 
                    receiptHeader={receiptHeader} setReceiptHeader={setReceiptHeader}
                    receiptFooter={receiptFooter} setReceiptFooter={setReceiptFooter}
                    receiptLogo={receiptLogo} setReceiptLogo={setReceiptLogo}
                    receiptColor={receiptColor} setReceiptColor={setReceiptColor}
                    currency={currency} setCurrency={setCurrency} 
                    developer={developerName} officialLabel={officialLabel} 
                    onResetData={() => setShowResetConfirm(true)}
                    posMode={posMode} setPosMode={setPosMode}
                    features={features} setFeatures={setFeatures}
                    onBackup={handleBackup}
                    onRestore={handleRestore}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
          
          {/* Footer Appreciations */}
          <div className="w-full py-4 px-6 border-t border-white/5 bg-black/50 backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-4 no-print z-10">
            <div className="flex items-center gap-4 text-[8px] font-black text-gray-500 uppercase tracking-widest">
              <span>Powered by:</span>
              <span className="flex items-center gap-1"><BrainCircuit size={10} className="text-purple-500"/> Multi-Claude Engine</span>
              <span className="flex items-center gap-1"><Cloud size={10} className="text-blue-500"/> Google Drive & iCloud Sync</span>
              <span className="flex items-center gap-1"><FileText size={10} className="text-green-500"/> Google Sheets</span>
            </div>
            <div className="text-[8px] font-black text-gray-600 uppercase tracking-widest">
              Realtime Backup & Sync Active • V2.0 Premium
            </div>
          </div>
        </main>
      </div>

      {/* Reset Confirmation Modal */}
      <AnimatePresence>
        {showResetConfirm && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
              className="bg-[#0a0a0a] border border-red-500/30 p-10 rounded-[48px] max-w-md w-full text-center shadow-[0_0_50px_rgba(239,68,68,0.1)]"
            >
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-8 border border-red-500/30">
                <AlertTriangle size={40} className="text-red-500" />
              </div>
              <h3 className="text-2xl font-black text-white uppercase mb-4 tracking-tighter italic">Konfirmasi Reset Data</h3>
              <p className="text-sm text-gray-400 mb-10 leading-relaxed font-medium">
                Tindakan ini akan menghapus seluruh data transaksi, produk, pelanggan, dan riwayat secara permanen. Apakah Anda yakin ingin melanjutkan?
              </p>
              <div className="flex flex-col gap-4">
                <button 
                  onClick={handleResetData}
                  disabled={isResetting}
                  className="w-full py-5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-black uppercase tracking-widest transition-all shadow-lg shadow-red-600/20 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isResetting ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Sedang Meriset...
                    </>
                  ) : (
                    "Ya, Hapus Semua Data"
                  )}
                </button>
                <button 
                  onClick={() => setShowResetConfirm(false)}
                  disabled={isResetting}
                  className="w-full py-5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-400 font-black uppercase tracking-widest transition-all border border-white/10"
                >
                  Batalkan
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Restore Confirmation Modal */}
      <AnimatePresence>
        {showRestoreConfirm && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
              className="bg-[#0a0a0a] border border-blue-500/30 p-10 rounded-[48px] max-w-md w-full text-center shadow-[0_0_50px_rgba(59,130,246,0.1)]"
            >
              <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-8 border border-blue-500/30">
                <Cloud size={40} className="text-blue-500" />
              </div>
              <h3 className="text-2xl font-black text-white uppercase mb-4 tracking-tighter italic">Konfirmasi Restore Data</h3>
              <p className="text-sm text-gray-400 mb-10 leading-relaxed font-medium">
                Apakah Anda yakin ingin memulihkan data dari backup? Tindakan ini akan menimpa data saat ini dengan data dari file backup.
              </p>
              <div className="flex flex-col gap-4">
                <button 
                  onClick={confirmRestore}
                  disabled={isRestoring}
                  className="w-full py-5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-600/20 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isRestoring ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Sedang Memulihkan...
                    </>
                  ) : (
                    "Ya, Pulihkan Data"
                  )}
                </button>
                <button 
                  onClick={() => { setShowRestoreConfirm(false); setBackupData(null); }}
                  disabled={isRestoring}
                  className="w-full py-5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-400 font-black uppercase tracking-widest transition-all border border-white/10"
                >
                  Batalkan
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}

function POSModule({ products, onCheckout, onExternalFund, storeName, developer, officialLabel, dailyStats, formatCurrency, db, receiptHeader, receiptFooter, receiptLogo, receiptColor, customers, setActiveTab, downloadReceiptPDF, posMode, features }: any) {
  const [cart, setCart] = useState<any[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [transactionForm, setTransactionForm] = useState({ price: '', qty: '' });
  const [showCartMobile, setShowCartMobile] = useState(false);
  const [showExternalModal, setShowExternalModal] = useState(false);
  const [externalTab, setExternalTab] = useState('EXPENSE');
  const [externalForm, setExternalForm] = useState({ note: '', amount: '', dueDate: '' });
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [priceSuggestions, setPriceSuggestions] = useState<string[]>([]);
  const [qtySuggestions, setQtySuggestions] = useState<string[]>([]);
  const [formError, setFormError] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastTransaction, setLastTransaction] = useState<any>(null);

  const formatInputNumber = (val: string) => {
    const digits = val.replace(/\D/g, '');
    if (!digits) return '';
    return new Intl.NumberFormat('id-ID').format(parseInt(digits));
  };

  const parseInputNumber = (val: string) => {
    return parseFloat(val.replace(/\./g, '')) || 0;
  };

  const total = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.qty), 0), [cart]);
  
  const totalExpenses = (dailyStats.expenses || []).reduce((sum: number, e: any) => sum + e.amount, 0);
  const totalIncomes = (dailyStats.incomes || []).reduce((sum: number, i: any) => sum + i.amount, 0);
  const netCash = (dailyStats.capital || 0) + (dailyStats.sales || 0) + totalIncomes - totalExpenses;

  const addNewProduct = async () => {
    if (!newItemName.trim() || !db) return;
    const prodPath = `artifacts/${appId}/public/data/products`;
    try {
      await addDoc(collection(db, prodPath), { 
        name: newItemName.toUpperCase(), 
        price: 0, 
        createdAt: new Date().toISOString() 
      });
      setNewItemName('');
    } catch (e) { handleFirestoreError(e, OperationType.CREATE, prodPath); }
  };

  const confirmToCart = () => {
    if (!selectedProduct) return;
    const price = parseInputNumber(transactionForm.price);
    const qty = parseFloat(transactionForm.qty) || 0;
    
    if (price <= 0) {
      setFormError('Harga harus lebih dari 0');
      return;
    }
    if (qty <= 0) {
      setFormError('Jumlah harus lebih dari 0');
      return;
    }

    if (!priceSuggestions.includes(transactionForm.price)) setPriceSuggestions([transactionForm.price, ...priceSuggestions].slice(0, 5));
    if (!qtySuggestions.includes(transactionForm.qty)) setQtySuggestions([transactionForm.qty, ...qtySuggestions].slice(0, 5));

    setCart([...cart, { ...selectedProduct, price, qty }]);
    setSelectedProduct(null);
    setTransactionForm({ price: '', qty: '' });
    setFormError('');
  };

  const updateCartItemQty = (idx: number, delta: number) => {
    const newCart = [...cart];
    const newQty = newCart[idx].qty + delta;
    if (newQty > 0) {
      newCart[idx].qty = newQty;
      setCart(newCart);
    } else if (newQty === 0) {
      setCart(cart.filter((_, i) => i !== idx));
    }
  };

  const updateCartItemPrice = (idx: number, val: string) => {
    const newCart = [...cart];
    newCart[idx].price = parseInputNumber(val);
    setCart(newCart);
  };

  const handleFinish = () => {
    const transactionData = {
      id: Math.floor(Math.random() * 1000000).toString().padStart(6, '0'),
      date: new Date().toISOString(),
      items: [...cart],
      total,
      mode: posMode,
      customer: selectedCustomer
    };
    onCheckout(total, posMode, cart, selectedCustomer);
    setLastTransaction(transactionData);
    setShowSuccessModal(true);
    setCart([]);
    setSelectedCustomer(null);
    setShowCartMobile(false);
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
      <div className="flex-1 flex flex-col p-4 md:p-6 overflow-hidden no-print">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2 mb-6">
          {/* Consolidated Kas & Modal Section */}
          <div className="bg-white/5 p-4 rounded-2xl border border-white/10 flex items-center justify-between group hover:bg-yellow-500/5 transition-all">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-yellow-500/10 rounded-xl flex items-center justify-center text-yellow-500">
                <Wallet size={20}/>
              </div>
              <div>
                <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Modal Awal</p>
                <h3 className="text-sm font-black text-white italic">{formatCurrency(dailyStats.capital)}</h3>
              </div>
            </div>
            <button 
              onClick={() => { setExternalTab('CAPITAL'); setExternalForm({note: 'INJEKSI MODAL', amount: '', dueDate: ''}); setShowExternalModal(true); }}
              className="w-8 h-8 bg-green-500/10 text-green-500 rounded-lg flex items-center justify-center hover:bg-green-500/20 transition-all"
              title="Injeksi Modal"
            >
              <PlusCircle size={16}/>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 lg:col-span-2">
            <div className="bg-yellow-500/5 p-4 rounded-2xl border border-yellow-500/10 flex items-center gap-4">
              <div className="w-10 h-10 bg-yellow-500/10 rounded-xl flex items-center justify-center text-yellow-500">
                <TrendingUp size={20}/>
              </div>
              <div>
                <p className="text-[8px] font-black text-yellow-500 uppercase tracking-widest">Sisa Modal</p>
                <h3 className="text-sm font-black text-yellow-500 italic">{formatCurrency(netCash)}</h3>
              </div>
            </div>
            <div className="bg-red-500/5 p-4 rounded-2xl border border-red-500/10 flex items-center gap-4">
              <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center text-red-500">
                <TrendingDown size={20}/>
              </div>
              <div>
                <p className="text-[8px] font-black text-red-500 uppercase tracking-widest">Biaya Keluar</p>
                <h3 className="text-sm font-black text-white">{formatCurrency(totalExpenses)}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3 mb-6">
            <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 flex gap-2">
                    {features.showIncome && (
                      <button onClick={() => { setExternalTab('INCOME'); setExternalForm({note: '', amount: '', dueDate: ''}); setShowExternalModal(true); }} className="flex-1 bg-blue-500/10 text-blue-500 border border-blue-500/20 px-4 py-3 rounded-xl font-black text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-500/20 transition-colors">
                          <PlusCircle size={14}/> Kas Masuk
                      </button>
                    )}
                    <button onClick={() => { setExternalTab('EXPENSE'); setExternalForm({note: '', amount: '', dueDate: ''}); setShowExternalModal(true); }} className="flex-1 bg-red-500/10 text-red-500 border border-red-500/20 px-4 py-3 rounded-xl font-black text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-red-500/20 transition-colors">
                        <MinusCircle size={14}/> Kas Keluar
                    </button>
                </div>
            </div>

            <div className="flex gap-2">
                <input id="new-product-name" type="text" placeholder="TAMBAH NAMA BARANG BARU..." value={newItemName} onChange={e => setNewItemName(e.target.value)}
                  className="flex-1 bg-black border border-white/10 rounded-xl py-2.5 px-4 text-[10px] focus:border-yellow-500 outline-none font-bold uppercase" />
                <button id="btn-add-product" onClick={addNewProduct} className="bg-white/10 text-white font-black px-5 rounded-xl text-[9px] uppercase hover:bg-white/20 transition-colors">
                  SIMPAN
                </button>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-2 pr-2 content-start">
          {products.map((p: any) => (
            <div key={p.id} id={`product-${p.id}`} onClick={() => { setSelectedProduct(p); setTransactionForm({price: p.price ? formatInputNumber(p.price.toString()) : '', qty: ''}); setFormError(''); }} 
                 className="compact-card p-2.5 rounded-xl cursor-pointer flex flex-col items-center justify-center text-center group">
              <Package size={16} className="text-gray-600 mb-1.5 group-hover:text-yellow-500 transition-colors" />
              <h4 className="text-[8px] font-black text-white/80 group-hover:text-yellow-500 uppercase line-clamp-2 leading-tight">{p.name}</h4>
              <p className="text-[7px] text-gray-500 mt-1.5 font-mono tracking-tighter">{formatCurrency(p.price)}</p>
            </div>
          ))}
        </div>

        <button id="btn-cart-mobile" onClick={() => setShowCartMobile(true)} className="md:hidden fixed bottom-24 right-6 w-14 h-14 bg-yellow-500 rounded-2xl flex items-center justify-center text-black shadow-2xl z-40 transform active:scale-90 transition-transform">
          <div className="relative">
            <ShoppingCart size={24}/>
            {cart.length > 0 && <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-black">{cart.length}</span>}
          </div>
        </button>
      </div>

      {/* Sidebar Keranjang */}
      <div id="cart-sidebar" className={`${showCartMobile ? 'fixed inset-0 z-[200] bg-black p-4' : 'hidden'} md:flex md:relative md:w-96 bg-[#080808] md:border-l md:border-yellow-900/20 flex flex-col no-print`}>
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt size={16} className="text-yellow-500"/>
            <h2 className="text-[10px] font-black uppercase tracking-widest text-yellow-500">Daftar Nota: {posMode}</h2>
          </div>
          <button onClick={() => setShowCartMobile(false)} className="md:hidden text-gray-500"><X size={24}/></button>
        </div>

        {/* Customer Selector */}
        {posMode === 'JUAL' && (
          <div className="p-4 border-b border-white/5 relative">
            <div className="flex items-center gap-2 mb-2">
              <Users size={12} className="text-gray-500"/>
              <span className="text-[8px] font-black uppercase tracking-widest text-gray-500">Pelanggan</span>
            </div>
            {selectedCustomer ? (
              <div className="flex items-center justify-between bg-yellow-500/10 p-3 rounded-xl border border-yellow-500/20">
                <div>
                  <p className="text-[10px] font-black text-white uppercase">{selectedCustomer.name}</p>
                  <p className="text-[8px] text-gray-500 font-bold">{selectedCustomer.phone}</p>
                </div>
                <button onClick={() => setSelectedCustomer(null)} className="text-gray-500 hover:text-red-500 transition-colors">
                  <X size={14}/>
                </button>
              </div>
            ) : (
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="CARI/PILIH PELANGGAN..." 
                  value={customerSearch}
                  onChange={e => { setCustomerSearch(e.target.value); setShowCustomerDropdown(true); }}
                  onFocus={() => setShowCustomerDropdown(true)}
                  className="w-full bg-black border border-white/10 rounded-xl py-2.5 px-4 text-[9px] font-bold uppercase outline-none focus:border-yellow-500"
                />
                {showCustomerDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-[#0f0f0f] border border-white/10 rounded-xl shadow-2xl z-[100] max-h-48 overflow-y-auto">
                    {customers.filter((c: any) => c.name.toLowerCase().includes(customerSearch.toLowerCase()) || c.phone.includes(customerSearch)).map((c: any) => (
                      <button 
                        key={c.id} 
                        onClick={() => { setSelectedCustomer(c); setShowCustomerDropdown(false); setCustomerSearch(''); }}
                        className="w-full text-left p-3 hover:bg-white/5 border-b border-white/5 last:border-0 transition-colors"
                      >
                        <p className="text-[9px] font-black text-white uppercase">{c.name}</p>
                        <p className="text-[7px] text-gray-500 font-bold">{c.phone}</p>
                      </button>
                    ))}
                    {customerSearch && !customers.some((c: any) => c.name.toLowerCase() === customerSearch.toLowerCase()) && (
                      <div className="p-3 text-center">
                        <p className="text-[7px] text-gray-500 uppercase mb-2">Pelanggan tidak ditemukan</p>
                        <button 
                          onClick={() => setActiveTab('customers')}
                          className="text-[8px] font-black text-yellow-500 uppercase hover:underline"
                        >
                          + Tambah Pelanggan Baru
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-700 text-center space-y-4">
                <ShoppingCart size={48} className="opacity-10"/>
                <p className="text-[9px] font-black uppercase tracking-widest">Belum Ada Item</p>
            </div>
          ) : cart.map((item, idx) => (
            <div key={idx} className="flex flex-col gap-2 bg-white/5 p-3 rounded-2xl border border-white/5 hover:border-white/10 transition-all">
              <div className="flex justify-between items-start">
                <p className="text-[10px] font-black uppercase text-white leading-tight flex-1 pr-2">{item.name}</p>
                <button onClick={() => setCart(cart.filter((_, i) => i !== idx))} className="text-red-900 hover:text-red-500 transition-colors p-1"><Trash2 size={14}/></button>
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 relative">
                  <span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-[8px]">Rp</span>
                  <input 
                    type="text" 
                    inputMode="numeric"
                    value={formatInputNumber(item.price.toString())}
                    onChange={(e) => updateCartItemPrice(idx, e.target.value)}
                    className="w-full bg-black border border-white/10 rounded-lg py-1.5 pl-6 pr-2 text-white text-[9px] font-bold outline-none focus:border-yellow-500"
                  />
                </div>
                <div className="flex items-center bg-black rounded-lg border border-white/10">
                  <button onClick={() => updateCartItemQty(idx, -1)} className="px-2 py-1.5 text-gray-400 hover:text-white">-</button>
                  <span className="text-[9px] font-bold w-6 text-center">{item.qty}</span>
                  <button onClick={() => updateCartItemQty(idx, 1)} className="px-2 py-1.5 text-gray-400 hover:text-white">+</button>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-black text-yellow-500">{formatCurrency(item.price * item.qty)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 bg-black border-t border-white/10 mb-20 md:mb-0 rounded-t-[32px]">
          <div className="flex justify-between text-[10px] font-black uppercase mb-4 px-2 items-center">
            <span className="text-gray-500">Total {posMode}</span>
            <span className={`text-xl font-mono italic ${posMode === 'JUAL' ? 'text-green-500' : 'text-blue-500'}`}>{formatCurrency(total)}</span>
          </div>
          <button id="btn-process-checkout" disabled={cart.length === 0} onClick={handleFinish} className={`w-full py-5 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all shadow-xl ${posMode === 'JUAL' ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white'} disabled:opacity-20 active:scale-95`}>
            PROSES & CETAK NOTA
          </button>
        </div>
      </div>

      {/* Modal Transaction Form */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#080808] border border-yellow-500/20 p-5 rounded-2xl w-full max-w-sm relative shadow-2xl"
            >
              <h3 className="text-sm font-black text-yellow-500 uppercase mb-4 line-clamp-2">{selectedProduct.name}</h3>
              
              {formError && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-red-500">
                  <AlertTriangle size={14}/>
                  <span className="text-[9px] font-black uppercase tracking-widest">{formError}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="text-[9px] font-black text-gray-500 uppercase mb-1.5 block">Harga Satuan</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-xs">Rp</span>
                    <input 
                      type="text" 
                      inputMode="numeric"
                      list="price-suggestions"
                      value={transactionForm.price} 
                      onChange={e => setTransactionForm({...transactionForm, price: formatInputNumber(e.target.value)})}
                      className="w-full bg-black border border-white/10 rounded-lg p-3 pl-8 text-white text-xs font-bold outline-none focus:border-yellow-500"
                      placeholder="0"
                    />
                    <datalist id="price-suggestions">
                      {priceSuggestions.map((s, i) => <option key={i} value={s} />)}
                    </datalist>
                  </div>
                </div>
                <div>
                  <label className="text-[9px] font-black text-gray-500 uppercase mb-1.5 block">Jumlah (Qty)</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      inputMode="numeric"
                      list="qty-suggestions"
                      value={transactionForm.qty} 
                      onChange={e => setTransactionForm({...transactionForm, qty: e.target.value.replace(/[^0-9.]/g, '')})}
                      className="w-full bg-black border border-white/10 rounded-lg p-3 text-white text-xs font-bold outline-none focus:border-yellow-500"
                      placeholder="0"
                    />
                    <datalist id="qty-suggestions">
                      {qtySuggestions.map((s, i) => <option key={i} value={s} />)}
                    </datalist>
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <button onClick={() => setSelectedProduct(null)} className="flex-1 py-3 rounded-lg text-[9px] font-black uppercase bg-white/5 text-gray-400 hover:bg-white/10 transition-colors">Batal</button>
                  <button onClick={confirmToCart} className="flex-1 py-3 rounded-lg text-[9px] font-black uppercase bg-yellow-500 text-black hover:bg-yellow-400 transition-colors">Tambah</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Modal External Fund */}
      <AnimatePresence>
        {showExternalModal && (
          <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#080808] border border-yellow-500/20 p-8 rounded-[32px] w-full max-w-md"
            >
              <div className="flex gap-1 mb-8 bg-black p-1 rounded-xl">
                <button onClick={() => { setExternalTab('CAPITAL'); setExternalForm({note: 'INJEKSI MODAL', amount: '', dueDate: ''}); }} className={`flex-1 py-3 rounded-lg text-[9px] font-black uppercase ${externalTab === 'CAPITAL' ? 'bg-green-600 text-white' : 'text-gray-500'}`}>Modal</button>
                {features.showIncome && (
                  <button onClick={() => { setExternalTab('INCOME'); setExternalForm({note: '', amount: '', dueDate: ''}); }} className={`flex-1 py-3 rounded-lg text-[9px] font-black uppercase ${externalTab === 'INCOME' ? 'bg-blue-600 text-white' : 'text-gray-500'}`}>Pemasukan</button>
                )}
                <button onClick={() => { setExternalTab('EXPENSE'); setExternalForm({note: '', amount: '', dueDate: ''}); }} className={`flex-1 py-3 rounded-lg text-[9px] font-black uppercase ${externalTab === 'EXPENSE' ? 'bg-red-600 text-white' : 'text-gray-500'}`}>Pengeluaran</button>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">Keterangan</label>
                  <input 
                    type="text" 
                    value={externalForm.note} 
                    onChange={e => setExternalForm({...externalForm, note: e.target.value})}
                    className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-yellow-500 uppercase"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">Jumlah Nominal</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">Rp</span>
                    <input 
                      type="text" 
                      inputMode="numeric"
                      value={externalForm.amount} 
                      onChange={e => setExternalForm({...externalForm, amount: formatInputNumber(e.target.value)})}
                      className="w-full bg-black border border-white/10 rounded-xl p-4 pl-10 text-white font-bold outline-none focus:border-yellow-500"
                      placeholder="0"
                    />
                  </div>
                </div>
                {externalTab === 'EXPENSE' && (
                  <div>
                    <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">Jatuh Tempo (Opsional)</label>
                    <input 
                      type="date" 
                      value={externalForm.dueDate} 
                      onChange={e => setExternalForm({...externalForm, dueDate: e.target.value})}
                      className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-yellow-500"
                    />
                  </div>
                )}
                <div className="flex gap-3 pt-4">
                  <button onClick={() => setShowExternalModal(false)} className="flex-1 py-4 rounded-xl text-[10px] font-black uppercase bg-white/5 text-gray-400">Batal</button>
                  <button onClick={() => { onExternalFund(externalTab, externalForm.note, parseInputNumber(externalForm.amount).toString(), externalForm.dueDate); setShowExternalModal(false); setExternalForm({note: '', amount: '', dueDate: ''}); }} className="flex-1 py-4 rounded-xl text-[10px] font-black uppercase bg-yellow-500 text-black">Simpan</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal Success Transaction */}
      <AnimatePresence>
        {showSuccessModal && lastTransaction && (
          <div className="fixed inset-0 z-[400] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="bg-[#0a0a0a] border border-yellow-500/20 p-8 rounded-[48px] w-full max-w-md shadow-[0_0_50px_rgba(234,179,8,0.1)] text-center"
            >
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/30">
                <CheckCircle2 size={40} className="text-green-500" />
              </div>
              <h3 className="text-2xl font-black text-white uppercase mb-2 tracking-tighter italic">Transaksi Berhasil!</h3>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-8">Nota #{lastTransaction.id} telah diproses</p>
              
              <div className="bg-white/5 rounded-3xl p-6 mb-8 border border-white/5 text-left">
                <div className="flex justify-between mb-4">
                  <span className="text-[9px] font-black text-gray-500 uppercase">Total Transaksi</span>
                  <span className="text-lg font-black text-yellow-500">{formatCurrency(lastTransaction.total)}</span>
                </div>
                <div className="space-y-2 max-h-32 overflow-y-auto pr-2">
                  {lastTransaction.items.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between text-[9px] font-bold text-gray-400">
                      <span>{item.name} x {item.qty}</span>
                      <span>{formatCurrency(item.price * item.qty)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <button 
                  onClick={() => window.print()}
                  className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group"
                >
                  <Printer size={20} className="text-yellow-500 group-hover:scale-110 transition-transform" />
                  <span className="text-[8px] font-black text-white uppercase tracking-widest">Cetak Nota</span>
                </button>
                <button 
                  onClick={() => downloadReceiptPDF(lastTransaction)}
                  className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group"
                >
                  <Download size={20} className="text-blue-500 group-hover:scale-110 transition-transform" />
                  <span className="text-[8px] font-black text-white uppercase tracking-widest">Unduh PDF</span>
                </button>
              </div>

              <button 
                onClick={() => setShowSuccessModal(false)}
                className="w-full py-5 rounded-2xl bg-yellow-500 text-black font-black uppercase tracking-widest shadow-xl shadow-yellow-500/20 active:scale-95 transition-all"
              >
                Transaksi Baru
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Layout Cetak Nota */}
      <div className="print-only hidden">
          <div className="receipt-container" style={{ borderTop: `4px solid ${receiptColor || '#000'}` }}>
              <div className="receipt-header">
                {receiptLogo && (
                  <img src={receiptLogo} alt="Logo" className="w-12 h-12 mx-auto mb-2 object-contain grayscale" />
                )}
                <h1 className="text-sm font-black uppercase mb-1" style={{ color: receiptColor || '#000' }}>{storeName}</h1>
                <div className="text-[7px] whitespace-pre-line opacity-80">{receiptHeader}</div>
              </div>
              
              <div className="receipt-divider" />
              
              <div className="flex justify-between text-[7px] mb-1">
                <span>NO: #{lastTransaction?.id}</span>
                <span>{lastTransaction && new Date(lastTransaction.date).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' })}</span>
              </div>

              {lastTransaction?.customer && (
                <div className="text-[7px] mb-3">
                  <p>PELANGGAN: <span className="font-bold uppercase">{lastTransaction.customer.name}</span></p>
                  <p>TELP: {lastTransaction.customer.phone}</p>
                </div>
              )}

              <p className="font-black text-center mb-3 border border-black py-1 text-[8px]">STRUK TRANSAKSI {lastTransaction?.mode}</p>
              
              <div className="space-y-2">
                {lastTransaction?.items.map((item: any, i: number) => (
                    <div key={i}>
                        <div className="receipt-item font-bold">
                           <span className="uppercase">{item.name}</span>
                        </div>
                        <div className="receipt-item text-[7px] italic opacity-80">
                           <span>{item.qty} x {formatCurrency(item.price)}</span>
                           <span>{formatCurrency(item.price * item.qty)}</span>
                        </div>
                    </div>
                ))}
              </div>

              <div className="receipt-divider" />
              
              <div className="receipt-total">
                <div className="flex justify-between">
                  <span>TOTAL</span>
                  <span>{lastTransaction && formatCurrency(lastTransaction.total)}</span>
                </div>
              </div>
              
              <div className="flex justify-between text-[7px] opacity-70 mt-1">
                <span>Metode:</span>
                <span>Tunai / Cash</span>
              </div>

              <div className="receipt-divider" />
              
              <div className="receipt-footer">
                <div className="whitespace-pre-line italic opacity-80">{receiptFooter}</div>
                
                <div className="mt-4 pt-2 border-t border-black/10">
                  <div className="border border-black p-1.5 inline-block bg-gray-50">
                    <p className="font-black text-[7px]">✓ {officialLabel}</p>
                    <p className="text-[6px] mt-0.5 opacity-60">Powered by {developer}</p>
                  </div>
                </div>
              </div>
          </div>
      </div>
    </div>
  );
}

function DailyReportModule({ stats, history, onCloseDay, formatCurrency, storeName, developer, officialLabel, downloadReceiptPDF, features }: any) {
  const [searchQuery, setSearchQuery] = useState('');
  const totalExpenses = (stats.expenses || []).reduce((sum: number, e: any) => sum + e.amount, 0);
  const totalIncomes = (stats.incomes || []).reduce((sum: number, i: any) => sum + i.amount, 0);
  const netCash = (stats.capital || 0) + (stats.sales || 0) + totalIncomes - totalExpenses;

  const chartData = useMemo(() => {
    const last7Days = history.slice(-6).map((h: any) => ({
      name: new Date(h.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }),
      Penjualan: h.sales,
      Pengeluaran: h.expensesTotal,
      Pemasukan: h.incomesTotal || 0,
    }));

    // Add current day
    last7Days.push({
      name: 'Hari Ini',
      Penjualan: stats.sales,
      Pengeluaran: totalExpenses,
      Pemasukan: totalIncomes,
    });

    return last7Days;
  }, [history, stats, totalExpenses, totalIncomes]);

  const filteredIncomes = useMemo(() => {
    if (!searchQuery.trim()) return stats.incomes || [];
    const q = searchQuery.toLowerCase();
    return (stats.incomes || []).filter((inc: any) => 
      inc.note.toLowerCase().includes(q) || 
      new Date(inc.time).toLocaleTimeString().toLowerCase().includes(q)
    );
  }, [stats.incomes, searchQuery]);

  const filteredExpenses = useMemo(() => {
    if (!searchQuery.trim()) return stats.expenses || [];
    const q = searchQuery.toLowerCase();
    return (stats.expenses || []).filter((exp: any) => 
      exp.note.toLowerCase().includes(q) || 
      new Date(exp.time).toLocaleTimeString().toLowerCase().includes(q)
    );
  }, [stats.expenses, searchQuery]);

  const handleDownloadCSV = () => {
    const headers = ["Kategori", "Keterangan", "Waktu", "Jumlah"];
    const rows = [
      ["MODAL AWAL", "-", "-", stats.capital],
      ["OMZET PENJUALAN", "-", "-", stats.sales],
      ...stats.incomes.map((inc: any) => ["DANA MASUK", inc.note, new Date(inc.time).toLocaleString(), inc.amount]),
      ...stats.expenses.map((exp: any) => ["BIAYA KELUAR", exp.note, new Date(exp.time).toLocaleString(), exp.amount]),
      ["KAS FISIK NET", "-", "-", netCash]
    ];

    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n"
      + rows.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Laporan_Harian_${new Date().toLocaleDateString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    
    // Header Premium
    doc.setFillColor(234, 179, 8); // Yellow-500
    doc.rect(0, 0, pageWidth, 45, 'F');
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text(storeName.toUpperCase(), 14, 22);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("LAPORAN RINGKASAN HARIAN PREMIUM", 14, 30);
    doc.text(`Tanggal: ${new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`, 14, 36);
    doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')}`, 14, 42);
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("RINGKASAN KEUANGAN", 14, 55);
    
    const summaryData = [
      ["Modal Awal", formatCurrency(stats.capital)],
      ["Penjualan Hari Ini", formatCurrency(stats.sales)],
      ["Total Biaya Keluar", formatCurrency(totalExpenses)],
      ["Sisa Modal (Kas Net)", formatCurrency(netCash)]
    ];

    if (features.showIncome) {
      summaryData.splice(2, 0, ["Total Dana Masuk", formatCurrency(totalIncomes)]);
    }

    autoTable(doc, {
      startY: 60,
      head: [["Keterangan", "Jumlah"]],
      body: summaryData,
      theme: 'striped',
      headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 4 },
      columnStyles: {
        1: { halign: 'right', fontStyle: 'bold' }
      }
    });

    let finalY = (doc as any).lastAutoTable.finalY || 60;
    
    if (features.showIncome) {
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text("DETAIL KAS MASUK", 14, finalY + 15);
      const incomesData = stats.incomes.map((inc: any) => [
        inc.note || "Penjualan",
        new Date(inc.time).toLocaleTimeString(),
        formatCurrency(inc.amount)
      ]);
      
      autoTable(doc, {
        startY: finalY + 20,
        head: [["Keterangan", "Waktu", "Jumlah"]],
        body: incomesData.length > 0 ? incomesData : [["-", "-", "-"]],
        theme: 'grid',
        headStyles: { fillColor: [59, 130, 246] },
        styles: { fontSize: 9 },
        columnStyles: {
          2: { halign: 'right' }
        }
      });
      finalY = (doc as any).lastAutoTable.finalY || finalY + 20;
    }

    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("DETAIL KAS KELUAR", 14, finalY + 15);
    const expensesData = stats.expenses.map((exp: any) => [
      exp.note || "Biaya Operasional",
      new Date(exp.time).toLocaleTimeString(),
      formatCurrency(exp.amount)
    ]);

    autoTable(doc, {
      startY: finalY + 20,
      head: [["Keterangan", "Waktu", "Jumlah"]],
      body: expensesData.length > 0 ? expensesData : [["-", "-", "-"]],
      theme: 'grid',
      headStyles: { fillColor: [239, 68, 68] },
      styles: { fontSize: 9 },
      columnStyles: {
        2: { halign: 'right' }
      }
    });

    // Footer Signatures
    finalY = (doc as any).lastAutoTable.finalY + 20;
    if (finalY > 240) {
      doc.addPage();
      finalY = 20;
    }
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Admin Keuangan,", 30, finalY + 10);
    doc.text("Mengetahui,", pageWidth - 80, finalY + 10);
    
    doc.setFont("helvetica", "normal");
    doc.text(`( ${developer} )`, 30, finalY + 40);
    doc.text("( ........................................ )", pageWidth - 80, finalY + 40);

    doc.save(`Laporan_Harian_${new Date().toLocaleDateString()}.pdf`);
  };

  const handleExportWord = async () => {
    const summaryRows = [
      new TableRow({ children: [new TableCell({ children: [new Paragraph("Modal Awal")] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(stats.capital) })], alignment: AlignmentType.RIGHT })] })] }),
      new TableRow({ children: [new TableCell({ children: [new Paragraph("Penjualan Hari Ini")] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(stats.sales) })], alignment: AlignmentType.RIGHT })] })] }),
    ];

    if (features.showIncome) {
      summaryRows.push(new TableRow({ children: [new TableCell({ children: [new Paragraph("Total Dana Masuk")] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(totalIncomes) })], alignment: AlignmentType.RIGHT })] })] }));
    }

    summaryRows.push(new TableRow({ children: [new TableCell({ children: [new Paragraph("Total Biaya Keluar")] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(totalExpenses) })], alignment: AlignmentType.RIGHT })] })] }));
    summaryRows.push(new TableRow({ children: [new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Sisa Modal (Kas Net)", bold: true })] })] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(netCash), bold: true })], alignment: AlignmentType.RIGHT })] })] }));

    const children: any[] = [
      new Paragraph({ text: storeName.toUpperCase(), heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER }),
      new Paragraph({ text: "LAPORAN RINGKASAN HARIAN PREMIUM", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }),
      new Paragraph({ text: `Tanggal: ${new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`, alignment: AlignmentType.RIGHT, spacing: { after: 200 } }),
      new Paragraph({ text: "" }),
      new Paragraph({ children: [new TextRun({ text: "RINGKASAN KEUANGAN", bold: true })], spacing: { after: 200 } }),
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: summaryRows,
      }),
      new Paragraph({ text: "", spacing: { before: 400 } }),
    ];

    if (features.showIncome) {
      children.push(new Paragraph({ children: [new TextRun({ text: "DETAIL KAS MASUK", bold: true })], spacing: { after: 200 } }));
      children.push(new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          new TableRow({ children: [new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keterangan", bold: true })] })], shading: { fill: "3B82F6" } }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Waktu", bold: true })] })], shading: { fill: "3B82F6" } }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Jumlah", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "3B82F6" } })] }),
          ...stats.incomes.map((inc: any) => new TableRow({
            children: [new TableCell({ children: [new Paragraph(inc.note || "Penjualan")] }), new TableCell({ children: [new Paragraph(new Date(inc.time).toLocaleTimeString())] }), new TableCell({ children: [new Paragraph({ text: formatCurrency(inc.amount), alignment: AlignmentType.RIGHT })] })]
          }))
        ]
      }));
      children.push(new Paragraph({ text: "", spacing: { before: 400 } }));
    }

    children.push(new Paragraph({ children: [new TextRun({ text: "DETAIL KAS KELUAR", bold: true })], spacing: { after: 200 } }));
    children.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({ children: [new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keterangan", bold: true })] })], shading: { fill: "EF4444" } }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Waktu", bold: true })] })], shading: { fill: "EF4444" } }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Jumlah", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "EF4444" } })] }),
        ...stats.expenses.map((exp: any) => new TableRow({
          children: [new TableCell({ children: [new Paragraph(exp.note || "Biaya Operasional")] }), new TableCell({ children: [new Paragraph(new Date(exp.time).toLocaleTimeString())] }), new TableCell({ children: [new Paragraph({ text: formatCurrency(exp.amount), alignment: AlignmentType.RIGHT })] })]
        }))
      ]
    }));

    children.push(new Paragraph({ text: "", spacing: { before: 800 } }));
    children.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: { top: { style: "none" }, bottom: { style: "none" }, left: { style: "none" }, right: { style: "none" }, insideHorizontal: { style: "none" }, insideVertical: { style: "none" } },
      rows: [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Admin Keuangan,", bold: true })], alignment: AlignmentType.CENTER })] }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Mengetahui,", bold: true })], alignment: AlignmentType.CENTER })] }),
          ]
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ text: "", spacing: { before: 1000 } })] }),
            new TableCell({ children: [new Paragraph({ text: "", spacing: { before: 1000 } })] }),
          ]
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ text: `( ${developer} )`, alignment: AlignmentType.CENTER })] }),
            new TableCell({ children: [new Paragraph({ text: "( ........................................ )", alignment: AlignmentType.CENTER })] }),
          ]
        }),
      ]
    }));

    children.push(new Paragraph({ text: `✓ ${officialLabel} - Oleh: ${developer}`, alignment: AlignmentType.CENTER, spacing: { before: 400 } }));

    const doc = new Document({
      sections: [{
        properties: {},
        children: children,
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Laporan_Harian_${new Date().toLocaleDateString()}.docx`);
  };

  return (
    <div className="flex-1 p-6 md:p-10 overflow-y-auto space-y-8">
       <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 no-print">
        <h2 className="text-2xl font-black italic text-white uppercase tracking-tighter flex items-center gap-3">
            <div className="w-2 h-10 bg-yellow-500 rounded-full"></div> Laporan Kas Hari Ini
        </h2>
        <div className="flex flex-wrap gap-3 w-full lg:w-auto">
          <button onClick={handleDownloadCSV} className="flex-1 lg:flex-none px-6 py-4 bg-white/5 hover:bg-white/10 text-gray-300 font-black rounded-2xl text-[10px] uppercase border border-white/5 transition-all flex items-center justify-center gap-2">
            <Download size={16} className="text-blue-500" /> CSV
          </button>
          <button onClick={handleExportWord} className="flex-1 lg:flex-none px-6 py-4 bg-white/5 hover:bg-white/10 text-gray-300 font-black rounded-2xl text-[10px] uppercase border border-white/5 transition-all flex items-center justify-center gap-2">
            <FileText size={16} className="text-blue-500" /> Word
          </button>
          <button onClick={handleExportPDF} className="flex-1 lg:flex-none px-6 py-4 bg-white/5 hover:bg-white/10 text-gray-300 font-black rounded-2xl text-[10px] uppercase border border-white/5 transition-all flex items-center justify-center gap-2">
            <Download size={16} className="text-red-500" /> PDF
          </button>
          <button onClick={() => window.print()} className="flex-1 lg:flex-none px-6 py-4 bg-white/5 hover:bg-white/10 text-gray-300 font-black rounded-2xl text-[10px] uppercase border border-white/5 transition-all flex items-center justify-center gap-2">
            <Printer size={16} className="text-yellow-500" /> Cetak
          </button>
          <button id="btn-close-day" onClick={onCloseDay} className="flex-1 lg:flex-none px-8 py-4 bg-red-600 hover:bg-red-500 text-white font-black rounded-2xl text-[10px] uppercase shadow-2xl shadow-red-900/40 transition-all active:scale-95">Tutup Buku</button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 no-print">
        <div className="glass-panel p-6 rounded-[32px]"><p className="text-[8px] font-black text-gray-500 uppercase mb-2">Modal Awal</p><h3 className="text-base font-black text-white">{formatCurrency(stats.capital)}</h3></div>
        <div className="glass-panel p-6 rounded-[32px] bg-yellow-500/5 border-yellow-500/30 ring-1 ring-yellow-500/20"><p className="text-[8px] font-black text-yellow-500 uppercase mb-2">Sisa Modal (Kas Net)</p><h3 className="text-xl font-black text-yellow-500 italic tracking-tight">{formatCurrency(netCash)}</h3></div>
        <div className="glass-panel p-6 rounded-[32px]"><p className="text-[8px] font-black text-green-500 uppercase mb-2">Omzet Penjualan</p><h3 className="text-base font-black text-white">{formatCurrency(stats.sales)}</h3></div>
        <div className="glass-panel p-6 rounded-[32px]"><p className="text-[8px] font-black text-red-500 uppercase mb-2">Total Biaya Out</p><h3 className="text-base font-black text-white">{formatCurrency(totalExpenses)}</h3></div>
      </div>

      <div className="no-print space-y-4">
        <h4 className="text-[10px] font-black uppercase text-yellow-500 tracking-widest px-4">Tren Keuangan (7 Hari Terakhir)</h4>
        <div className="glass-panel p-6 rounded-[32px] h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
              <XAxis 
                dataKey="name" 
                stroke="#666" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
              />
              <YAxis 
                stroke="#666" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
                tickFormatter={(value) => `Rp ${value / 1000}k`}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#080808', border: '1px solid #333', borderRadius: '12px', fontSize: '10px' }}
                itemStyle={{ fontWeight: 'bold' }}
              />
              <Legend wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
              <Bar dataKey="Penjualan" fill="#22c55e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Pengeluaran" fill="#ef4444" radius={[4, 4, 0, 0]} />
              {features.showIncome && <Bar dataKey="Pemasukan" fill="#3b82f6" radius={[4, 4, 0, 0]} />}
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="relative no-print">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
        <input 
          type="text" 
          placeholder="CARI TRANSAKSI (KETERANGAN ATAU WAKTU)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#080808] border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-xs font-bold outline-none focus:border-yellow-500 uppercase transition-all"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 no-print">
        {features.showIncome && (
          <div className="space-y-4">
            <h4 className="text-[10px] font-black uppercase text-blue-500 tracking-widest px-4">Detail Kas Masuk</h4>
            <div className="space-y-2">
              {filteredIncomes.map((inc: any, idx: number) => (
                <div key={idx} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex justify-between items-center group">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-[10px] font-black uppercase text-white">{inc.note}</p>
                      <p className="text-[8px] text-gray-500 font-mono">{new Date(inc.time).toLocaleTimeString()}</p>
                    </div>
                    {inc.items && (
                      <button 
                        onClick={() => downloadReceiptPDF(inc)}
                        className="opacity-0 group-hover:opacity-100 p-2 bg-yellow-500/10 text-yellow-500 rounded-lg transition-all hover:bg-yellow-500/20"
                        title="Cetak Ulang Nota"
                      >
                        <Printer size={14} />
                      </button>
                    )}
                  </div>
                  <span className="text-[10px] font-black text-blue-500">{formatCurrency(inc.amount)}</span>
                </div>
              ))}
              {filteredIncomes.length === 0 && (
                <div className="p-8 text-center text-gray-600 text-[10px] font-bold uppercase opacity-50">Tidak ada data kas masuk</div>
              )}
            </div>
          </div>
        )}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black uppercase text-red-500 tracking-widest px-4">Detail Kas Keluar</h4>
          <div className="space-y-2">
            {filteredExpenses.map((exp: any, idx: number) => (
              <div key={idx} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-black uppercase text-white">{exp.note}</p>
                  <p className="text-[8px] text-gray-500 font-mono">{new Date(exp.time).toLocaleTimeString()}</p>
                </div>
                <span className="text-[10px] font-black text-red-500">{formatCurrency(exp.amount)}</span>
              </div>
            ))}
            {filteredExpenses.length === 0 && (
              <div className="p-8 text-center text-gray-600 text-[10px] font-bold uppercase opacity-50">Tidak ada data kas keluar</div>
            )}
          </div>
        </div>
      </div>

      {/* Layout Cetak Laporan Harian */}
      <div className="print-only hidden text-black">
          <div className="text-center mb-8 border-b-2 border-black pb-4">
            <h1 className="text-3xl font-black uppercase tracking-tighter">{storeName}</h1>
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] mt-2">Laporan Ringkasan Harian Premium</p>
          </div>

          <div className="flex justify-between items-start mb-8">
             <div>
                <h2 className="text-xl font-bold uppercase mb-1">Ringkasan Kas Hari Ini</h2>
                <p className="text-sm font-mono">{new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
             </div>
             <div className="text-right">
                <div className="official-stamp text-blue-800 font-bold">✓ {officialLabel}</div>
                <p className="mt-2 text-[10px] font-bold italic opacity-50">Dicetak pada: {new Date().toLocaleTimeString('id-ID')}</p>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Modal Awal</p>
              <p className="text-xl font-black">{formatCurrency(stats.capital)}</p>
            </div>
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Penjualan Hari Ini</p>
              <p className="text-xl font-black">{formatCurrency(stats.sales)}</p>
            </div>
            {features.showIncome && (
              <div className="border border-black p-4">
                <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Dana Masuk</p>
                <p className="text-xl font-black">{formatCurrency(totalIncomes)}</p>
              </div>
            )}
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Biaya Keluar</p>
              <p className="text-xl font-black">{formatCurrency(totalExpenses)}</p>
            </div>
            <div className="col-span-2 border border-black p-4 bg-gray-100">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Sisa Modal (Kas Net)</p>
              <p className="text-2xl font-black">{formatCurrency(netCash)}</p>
            </div>
          </div>

          <div className="space-y-8">
              {features.showIncome && (
                <div>
                    <h4 className="text-xs font-black uppercase mb-3 border-l-4 border-black pl-3">Detail Arus Kas Masuk</h4>
                    <table className="w-full text-[9px] border-collapse">
                        <thead>
                            <tr className="bg-gray-100 font-black uppercase border border-black">
                                <th className="p-2 border border-black text-center w-12">No</th>
                                <th className="p-2 border border-black text-left">Keterangan / Sumber Dana</th>
                                <th className="p-2 border border-black text-center w-24">Waktu</th>
                                <th className="p-2 border border-black text-right w-32">Nominal</th>
                            </tr>
                        </thead>
                        <tbody>
                          {stats.incomes?.map((inc: any, i: number) => (
                              <tr key={i} className="border border-black">
                                  <td className="p-2 border border-black text-center">{i + 1}</td>
                                  <td className="p-2 border border-black">{inc.note || "Penjualan"}</td>
                                  <td className="p-2 border border-black text-center">{new Date(inc.time).toLocaleTimeString('id-ID')}</td>
                                  <td className="p-2 border border-black text-right font-bold">{formatCurrency(inc.amount)}</td>
                              </tr>
                          ))}
                          {stats.incomes?.length === 0 && <tr><td colSpan={4} className="p-4 text-center italic border border-black">Tidak ada data kas masuk hari ini</td></tr>}
                        </tbody>
                    </table>
                </div>
              )}

              <div>
                  <h4 className="text-xs font-black uppercase mb-3 border-l-4 border-black pl-3">Detail Arus Kas Keluar</h4>
                  <table className="w-full text-[9px] border-collapse">
                      <thead>
                          <tr className="bg-gray-100 font-black uppercase border border-black">
                              <th className="p-2 border border-black text-center w-12">No</th>
                              <th className="p-2 border border-black text-left">Keterangan / Keperluan</th>
                              <th className="p-2 border border-black text-center w-24">Waktu</th>
                              <th className="p-2 border border-black text-right w-32">Nominal</th>
                          </tr>
                      </thead>
                      <tbody>
                        {stats.expenses?.map((exp: any, i: number) => (
                            <tr key={i} className="border border-black">
                                <td className="p-2 border border-black text-center">{i + 1}</td>
                                <td className="p-2 border border-black">
                                  {exp.note || "Biaya Operasional"}
                                  {exp.dueDate && (
                                    <span className="ml-2 text-[7px] font-bold italic opacity-50">
                                      (Jatuh Tempo: {new Date(exp.dueDate).toLocaleDateString('id-ID')})
                                    </span>
                                  )}
                                </td>
                                <td className="p-2 border border-black text-center">{new Date(exp.time).toLocaleTimeString('id-ID')}</td>
                                <td className="p-2 border border-black text-right font-bold">{formatCurrency(exp.amount)}</td>
                            </tr>
                        ))}
                        {stats.expenses?.length === 0 && <tr><td colSpan={4} className="p-4 text-center italic border border-black">Tidak ada data kas keluar hari ini</td></tr>}
                      </tbody>
                  </table>
              </div>
          </div>

          <div className="mt-20 flex justify-between px-10 text-[9px] font-bold uppercase">
              <div className="text-center w-48">
                  <p className="mb-16 italic opacity-50">Disiapkan Oleh,</p>
                  <div className="border-t-2 border-black pt-2 font-black">{developer}</div>
                  <p className="text-[7px] mt-1 opacity-50">Admin Keuangan</p>
              </div>
              <div className="text-center w-48">
                  <p className="mb-16 italic opacity-50">Mengetahui,</p>
                  <div className="border-t-2 border-black pt-2 font-black">Manager Operasional</div>
                  <p className="text-[7px] mt-1 opacity-50">Pimpinan Toko</p>
              </div>
          </div>
          
          <div className="mt-12 text-center text-[7px] text-gray-400 font-bold uppercase tracking-widest">
            Laporan ini dihasilkan secara resmi oleh {storeName} - {officialLabel}
          </div>
      </div>
    </div>
  );
}

function CustomersModule({ customers, history, dailyStats, formatCurrency, db }: any) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '' });
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleAddCustomer = async () => {
    if (!newCustomer.name || !newCustomer.phone || !db) return;
    const custPath = `artifacts/${appId}/public/data/customers`;
    try {
      await addDoc(collection(db, custPath), {
        ...newCustomer,
        createdAt: new Date().toISOString()
      });
      setNewCustomer({ name: '', phone: '' });
      setShowAddModal(false);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, custPath);
    }
  };

  const getCustomerHistory = (customerId: string) => {
    const dailySales = (dailyStats.incomes || []).filter((inc: any) => inc.customerId === customerId);
    const archivedSales = history.flatMap((h: any) => (h.incomes || []).filter((inc: any) => inc.customerId === customerId));
    return [...dailySales, ...archivedSales].sort((a: any, b: any) => new Date(b.time).getTime() - new Date(a.time).getTime());
  };

  const filteredCustomers = customers.filter((c: any) => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.phone.includes(searchQuery)
  );

  return (
    <div className="flex-1 flex flex-col p-6 md:p-10 overflow-hidden no-print">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-yellow-500 rounded-2xl flex items-center justify-center text-black shadow-lg">
            <Users size={24}/>
          </div>
          <div>
            <h2 className="text-xl font-black text-white uppercase tracking-tighter">Manajemen Pelanggan</h2>
            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Database & Riwayat Transaksi</p>
          </div>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-yellow-500 text-black px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-yellow-400 transition-all active:scale-95 shadow-xl shadow-yellow-500/20"
        >
          <UserPlus size={16}/> Tambah Pelanggan
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-8 flex-1 overflow-hidden">
        {/* Customer List */}
        <div className="flex-1 flex flex-col glass-panel rounded-[40px] overflow-hidden">
          <div className="p-6 border-b border-white/5">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input 
                type="text" 
                placeholder="CARI PELANGGAN..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 pl-12 pr-6 text-xs font-bold outline-none focus:border-yellow-500 uppercase transition-all"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {filteredCustomers.map((c: any) => (
              <button 
                key={c.id} 
                onClick={() => setSelectedCustomer(c)}
                className={`w-full flex items-center justify-between p-5 rounded-2xl border transition-all ${selectedCustomer?.id === c.id ? 'bg-yellow-500/10 border-yellow-500/50 shadow-lg' : 'bg-white/5 border-white/5 hover:border-white/10'}`}
              >
                <div className="text-left">
                  <p className="text-xs font-black text-white uppercase mb-1">{c.name}</p>
                  <p className="text-[10px] text-gray-500 font-bold tracking-widest">{c.phone}</p>
                </div>
                <div className="text-right">
                  <p className="text-[8px] text-gray-600 font-black uppercase tracking-widest mb-1">Total Transaksi</p>
                  <p className="text-xs font-black text-yellow-500">{getCustomerHistory(c.id).length}</p>
                </div>
              </button>
            ))}
            {filteredCustomers.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-gray-700 opacity-30 py-20">
                <Users size={64} />
                <p className="text-[10px] font-black uppercase mt-4 tracking-widest">Tidak ada pelanggan ditemukan</p>
              </div>
            )}
          </div>
        </div>

        {/* Customer Details & History */}
        <div className="w-full md:w-[450px] flex flex-col glass-panel rounded-[40px] overflow-hidden bg-black/20">
          {selectedCustomer ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-8 bg-gradient-to-br from-yellow-500/10 to-transparent border-b border-white/5">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-yellow-500 rounded-3xl flex items-center justify-center text-black shadow-2xl">
                    <span className="text-2xl font-black">{selectedCustomer.name.charAt(0).toUpperCase()}</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-tighter">{selectedCustomer.name}</h3>
                    <p className="text-xs text-gray-500 font-bold tracking-widest">{selectedCustomer.phone}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                    <p className="text-[8px] font-black text-gray-500 uppercase mb-1">Bergabung Sejak</p>
                    <p className="text-[10px] font-bold text-white">{new Date(selectedCustomer.createdAt).toLocaleDateString('id-ID')}</p>
                  </div>
                  <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                    <p className="text-[8px] font-black text-gray-500 uppercase mb-1">Total Belanja</p>
                    <p className="text-[10px] font-bold text-yellow-500">
                      {formatCurrency(getCustomerHistory(selectedCustomer.id).reduce((sum, h) => sum + h.amount, 0))}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <History size={12}/> Riwayat Pembelian
                </h4>
                {getCustomerHistory(selectedCustomer.id).map((h: any, idx: number) => (
                  <div key={idx} className="bg-white/5 p-5 rounded-2xl border border-white/5 hover:border-white/10 transition-all">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="text-[10px] font-black text-white uppercase mb-1">Transaksi #{idx + 1}</p>
                        <p className="text-[8px] text-gray-500 font-bold">{new Date(h.time).toLocaleString('id-ID')}</p>
                      </div>
                      <span className="text-xs font-black text-green-500">{formatCurrency(h.amount)}</span>
                    </div>
                    {h.items && (
                      <div className="space-y-1 pt-2 border-t border-white/5">
                        {h.items.map((item: any, i: number) => (
                          <div key={i} className="flex justify-between text-[8px] font-bold uppercase text-gray-400">
                            <span>{item.name} x {item.qty}</span>
                            <span>{formatCurrency(item.price * item.qty)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                {getCustomerHistory(selectedCustomer.id).length === 0 && (
                  <div className="text-center py-10 opacity-30">
                    <p className="text-[9px] font-black uppercase tracking-widest">Belum ada riwayat transaksi</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-10 opacity-30">
              <Users size={80} className="mb-6 text-yellow-500" />
              <h3 className="text-lg font-black text-white uppercase tracking-tighter mb-2">Pilih Pelanggan</h3>
              <p className="text-[10px] font-bold uppercase tracking-widest max-w-xs">Pilih pelanggan dari daftar di samping untuk melihat detail profil dan riwayat transaksi mereka.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Customer Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#080808] border border-yellow-500/20 p-10 rounded-[48px] w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-10">
                <div className="w-12 h-12 bg-yellow-500 rounded-2xl flex items-center justify-center text-black">
                  <UserPlus size={24}/>
                </div>
                <div>
                  <h3 className="text-xl font-black text-white uppercase tracking-tighter">Pelanggan Baru</h3>
                  <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Daftarkan pelanggan ke sistem</p>
                </div>
              </div>
              
              <div className="space-y-8">
                <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase mb-3 block tracking-widest">Nama Lengkap</label>
                  <input 
                    type="text" 
                    value={newCustomer.name} 
                    onChange={e => setNewCustomer({...newCustomer, name: e.target.value})}
                    placeholder="CONTOH: BUDI SANTOSO"
                    className="w-full bg-black border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-yellow-500 uppercase transition-all"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase mb-3 block tracking-widest">Nomor Telepon / WA</label>
                  <input 
                    type="text" 
                    value={newCustomer.phone} 
                    onChange={e => setNewCustomer({...newCustomer, phone: e.target.value})}
                    placeholder="CONTOH: 081234567890"
                    className="w-full bg-black border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-yellow-500 transition-all"
                  />
                </div>
                <div className="flex gap-4 pt-6">
                  <button 
                    onClick={() => setShowAddModal(false)} 
                    className="flex-1 py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-white/5 text-gray-500 hover:bg-white/10 transition-all"
                  >
                    Batal
                  </button>
                  <button 
                    onClick={handleAddCustomer} 
                    className="flex-1 py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-yellow-500 text-black shadow-xl shadow-yellow-500/20 active:scale-95 transition-all"
                  >
                    Simpan Data
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ReportsModule({ history, formatCurrency, storeName, developer, officialLabel, features }: any) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [filterProduct, setFilterProduct] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  const allProducts = useMemo(() => {
    const products = new Set<string>();
    history.forEach((h: any) => {
      [...(h.incomes || []), ...(h.expenses || [])].forEach((entry: any) => {
        if (entry.items) {
          entry.items.forEach((item: any) => products.add(item.name));
        } else if (entry.note) {
          // Fallback for non-itemized entries
          products.add(entry.note);
        }
      });
    });
    return Array.from(products).sort();
  }, [history]);

  const filteredHistory = useMemo(() => {
    return history.filter((h: any) => {
      const hDate = new Date(h.date);
      const start = startDate ? new Date(startDate) : null;
      const end = endDate ? new Date(endDate) : null;
      
      if (start && hDate < start) return false;
      if (end) {
        const adjustedEnd = new Date(end);
        adjustedEnd.setHours(23, 59, 59, 999);
        if (hDate > adjustedEnd) return false;
      }

      if (filterProduct) {
        const hasProduct = [...(h.incomes || []), ...(h.expenses || [])].some((entry: any) => {
          if (entry.items) {
            return entry.items.some((item: any) => item.name === filterProduct);
          }
          return entry.note === filterProduct;
        });
        if (!hasProduct) return false;
      }

      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesNote = h.note?.toLowerCase().includes(query);
        const matchesTransactions = [...(h.incomes || []), ...(h.expenses || [])].some((entry: any) => {
          const noteMatch = entry.note?.toLowerCase().includes(query);
          const itemMatch = entry.items?.some((item: any) => item.name.toLowerCase().includes(query));
          return noteMatch || itemMatch;
        });
        if (!matchesNote && !matchesTransactions) return false;
      }

      return true;
    });
  }, [history, startDate, endDate, filterProduct, searchQuery]);

  const chartData = useMemo(() => {
    return [...filteredHistory].reverse().map((h: any) => ({
      name: new Date(h.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }),
      fullDate: new Date(h.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }),
      revenue: h.sales + (h.incomesTotal || 0),
      expenses: h.expensesTotal || 0,
      profit: h.netCash || 0,
      sales: h.sales || 0,
      incomes: h.incomesTotal || 0
    }));
  }, [filteredHistory]);

  const monthlyChartData = useMemo(() => {
    const monthlyData: Record<string, any> = {};
    [...filteredHistory].reverse().forEach((h: any) => {
      const date = new Date(h.date);
      const monthYear = date.toLocaleDateString('id-ID', { month: 'short', year: 'numeric' });
      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = {
          name: monthYear,
          fullDate: monthYear,
          sales: 0,
          expenses: 0,
          profit: 0
        };
      }
      monthlyData[monthYear].sales += (h.sales || 0);
      monthlyData[monthYear].expenses += (h.expensesTotal || 0);
      monthlyData[monthYear].profit += (h.netCash || 0);
    });
    return Object.values(monthlyData);
  }, [filteredHistory]);

  const totals = useMemo(() => {
    return filteredHistory.reduce((acc: any, h: any) => {
      acc.capital += (h.capital || 0);
      acc.sales += (h.sales || 0);
      acc.incomes += (h.incomesTotal || 0);
      acc.expenses += (h.expensesTotal || 0);
      acc.netCash += (h.netCash || 0);
      return acc;
    }, { capital: 0, sales: 0, incomes: 0, expenses: 0, netCash: 0 });
  }, [filteredHistory]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#080808] border border-white/10 p-4 rounded-2xl shadow-2xl backdrop-blur-md">
          <p className="text-[10px] font-black text-gray-500 uppercase mb-2 tracking-widest">{payload[0].payload.fullDate}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-8 mb-1">
              <span className="text-[9px] font-bold uppercase tracking-tighter" style={{ color: entry.color }}>{entry.name}:</span>
              <span className="text-[10px] font-black text-white">{formatCurrency(entry.value)}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    
    // Header Premium
    doc.setFillColor(234, 179, 8); // Yellow-500
    doc.rect(0, 0, pageWidth, 45, 'F');
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text(storeName.toUpperCase(), 14, 22);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("LAPORAN KEUANGAN PREMIUM - ARSIP REKAPAN", 14, 30);
    doc.text(`Periode: ${startDate || 'Awal'} s/d ${endDate || 'Sekarang'}`, 14, 36);
    doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')}`, 14, 42);
    
    // Summary Table
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("RINGKASAN KEUANGAN", 14, 55);
    
    const summaryColumns = ["Keterangan", "Total"];
    const summaryRows = [
      ["Total Modal Awal", formatCurrency(totals.capital)],
      ["Total Penjualan", formatCurrency(totals.sales)],
      ["Total Pengeluaran", formatCurrency(totals.expenses)],
      ["Total Kas Net (Saldo Akhir)", formatCurrency(totals.netCash)]
    ];
    
    if (features.showIncome) {
      summaryRows.splice(2, 0, ["Total Sisa Modal", formatCurrency(totals.incomes)]);
    }

    autoTable(doc, {
      startY: 60,
      head: [summaryColumns],
      body: summaryRows,
      theme: 'striped',
      headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 4 },
      columnStyles: { 1: { halign: 'right', fontStyle: 'bold' } }
    });

    let currentY = (doc as any).lastAutoTable.finalY + 15;

    // Detailed History Table
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("REKAPITULASI HARIAN", 14, currentY);
    
    const historyColumns = ["Tanggal", "Modal", "Penjualan", "Biaya Out", "Kas Net"];
    if (features.showIncome) historyColumns.splice(3, 0, "Sisa Modal");

    const historyRows = filteredHistory.map((h: any) => {
      const row = [
        new Date(h.date).toLocaleDateString('id-ID'),
        formatCurrency(h.capital || 0),
        formatCurrency(h.sales),
        formatCurrency(h.expensesTotal),
        formatCurrency(h.netCash)
      ];
      if (features.showIncome) row.splice(3, 0, formatCurrency(h.incomesTotal || 0));
      return row;
    });

    autoTable(doc, {
      startY: currentY + 5,
      head: [historyColumns],
      body: historyRows,
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: [255, 255, 255] },
      styles: { fontSize: 8, cellPadding: 3 },
      columnStyles: {
        1: { halign: 'right' },
        2: { halign: 'right' },
        3: { halign: 'right' },
        4: { halign: 'right' },
        5: { halign: 'right' }
      }
    });

    currentY = (doc as any).lastAutoTable.finalY + 20;

    // Detailed Transactions (Per Nota)
    doc.addPage();
    currentY = 20;
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text("RINCIAN TRANSAKSI PER NOTA", 14, currentY);
    currentY += 10;

    filteredHistory.forEach((h: any) => {
      if (currentY > 250) {
        doc.addPage();
        currentY = 20;
      }

      doc.setFillColor(245, 245, 245);
      doc.rect(14, currentY, pageWidth - 28, 8, 'F');
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text(`TANGGAL: ${new Date(h.date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`, 18, currentY + 5.5);
      currentY += 12;

      const transData: any[] = [];
      
      // Incomes (Sales/Income)
      (h.incomes || []).forEach((inc: any) => {
        transData.push([
          new Date(inc.time).toLocaleTimeString(),
          "MASUK",
          inc.note || "Penjualan",
          formatCurrency(inc.amount)
        ]);
        if (inc.items && inc.items.length > 0) {
          inc.items.forEach((item: any) => {
            transData.push([
              "",
              "",
              `   > ${item.name} (${item.quantity}x @ ${formatCurrency(item.price)})`,
              ""
            ]);
          });
        }
      });

      // Expenses
      (h.expenses || []).forEach((exp: any) => {
        transData.push([
          new Date(exp.time).toLocaleTimeString(),
          "KELUAR",
          exp.note || "Biaya Operasional",
          formatCurrency(exp.amount)
        ]);
      });

      if (transData.length > 0) {
        autoTable(doc, {
          startY: currentY,
          head: [["Waktu", "Tipe", "Keterangan / Item", "Jumlah"]],
          body: transData,
          theme: 'plain',
          styles: { fontSize: 8, cellPadding: 2 },
          headStyles: { fontStyle: 'bold', lineWidth: 0.1, lineColor: [0, 0, 0] },
          columnStyles: { 3: { halign: 'right' } },
          margin: { left: 20 }
        });
        currentY = (doc as any).lastAutoTable.finalY + 15;
      } else {
        doc.setFont("helvetica", "italic");
        doc.setFontSize(8);
        doc.text("Tidak ada transaksi detail pada tanggal ini.", 20, currentY);
        currentY += 15;
      }
    });

    // Footer with Signature
    if (currentY > 230) {
      doc.addPage();
      currentY = 20;
    }
    
    const signatureY = currentY + 20;
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Tanda Tangan Pengelola", 30, signatureY);
    doc.text("Tanda Tangan Saksi", pageWidth - 80, signatureY);
    
    doc.setFont("helvetica", "normal");
    doc.text("( ........................................ )", 30, signatureY + 30);
    doc.text("( ........................................ )", pageWidth - 80, signatureY + 30);

    doc.save(`Laporan_Premium_${new Date().getTime()}.pdf`);
  };

  const exportToWord = async () => {
    const sections: any[] = [
      new Paragraph({
        text: storeName.toUpperCase(),
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
      }),
      new Paragraph({
        text: "LAPORAN KEUANGAN PREMIUM - ARSIP REKAPAN",
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 },
      }),
      new Paragraph({
        children: [
          new TextRun({ text: `Periode: ${startDate || 'Awal'} s/d ${endDate || 'Sekarang'}`, size: 18 }),
        ],
        alignment: AlignmentType.CENTER,
      }),
      new Paragraph({
        children: [
          new TextRun({ text: `Dicetak pada: ${new Date().toLocaleString('id-ID')}`, size: 18 }),
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 },
      }),
    ];

    // Summary Table
    sections.push(new Paragraph({ children: [new TextRun({ text: "RINGKASAN KEUANGAN", bold: true })], spacing: { before: 400, after: 200 } }));
    
    const summaryRows = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keterangan", bold: true })] })], shading: { fill: "EAB308" } }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Total", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "EAB308" } }),
        ]
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Total Modal Awal")] }),
          new TableCell({ children: [new Paragraph({ text: formatCurrency(totals.capital), alignment: AlignmentType.RIGHT })] }),
        ]
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Total Penjualan")] }),
          new TableCell({ children: [new Paragraph({ text: formatCurrency(totals.sales), alignment: AlignmentType.RIGHT })] }),
        ]
      })
    ];

    if (features.showIncome) {
      summaryRows.push(new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Total Sisa Modal")] }),
          new TableCell({ children: [new Paragraph({ text: formatCurrency(totals.incomes), alignment: AlignmentType.RIGHT })] }),
        ]
      }));
    }

    summaryRows.push(new TableRow({
      children: [
        new TableCell({ children: [new Paragraph("Total Pengeluaran")] }),
        new TableCell({ children: [new Paragraph({ text: formatCurrency(totals.expenses), alignment: AlignmentType.RIGHT })] }),
      ]
    }));

    summaryRows.push(new TableRow({
      children: [
        new TableCell({ children: [new Paragraph("Total Kas Net (Saldo Akhir)")] }),
        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(totals.netCash), bold: true })], alignment: AlignmentType.RIGHT })] }),
      ]
    }));

    sections.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: summaryRows
    }));

    // Detailed History
    sections.push(new Paragraph({ children: [new TextRun({ text: "REKAPITULASI HARIAN", bold: true })], spacing: { before: 600, after: 200 } }));
    
    const historyHeaderCells = [
      new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Tanggal", bold: true })] })], shading: { fill: "323232" } }),
      new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Modal", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "323232" } }),
      new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Penjualan", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "323232" } }),
    ];
    if (features.showIncome) historyHeaderCells.push(new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Sisa Modal", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "323232" } }));
    historyHeaderCells.push(new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Biaya Out", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "323232" } }));
    historyHeaderCells.push(new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Kas Net", bold: true })], alignment: AlignmentType.RIGHT })], shading: { fill: "323232" } }));

    const historyRows = [new TableRow({ children: historyHeaderCells })];

    filteredHistory.forEach((h: any) => {
      const cells = [
        new TableCell({ children: [new Paragraph(new Date(h.date).toLocaleDateString('id-ID'))] }),
        new TableCell({ children: [new Paragraph({ text: formatCurrency(h.capital || 0), alignment: AlignmentType.RIGHT })] }),
        new TableCell({ children: [new Paragraph({ text: formatCurrency(h.sales), alignment: AlignmentType.RIGHT })] }),
      ];
      if (features.showIncome) cells.push(new TableCell({ children: [new Paragraph({ text: formatCurrency(h.incomesTotal || 0), alignment: AlignmentType.RIGHT })] }));
      cells.push(new TableCell({ children: [new Paragraph({ text: formatCurrency(h.expensesTotal), alignment: AlignmentType.RIGHT })] }));
      cells.push(new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: formatCurrency(h.netCash), bold: true })], alignment: AlignmentType.RIGHT })] }));
      
      historyRows.push(new TableRow({ children: cells }));
    });

    sections.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: historyRows
    }));

    // Per Nota Details
    sections.push(new Paragraph({ children: [new TextRun({ text: "RINCIAN TRANSAKSI PER NOTA", bold: true })], spacing: { before: 600, after: 200 } }));

    filteredHistory.forEach((h: any) => {
      sections.push(new Paragraph({
        children: [new TextRun({ text: `TANGGAL: ${new Date(h.date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`, bold: true })],
        shading: { fill: "F5F5F5" },
        spacing: { before: 300, after: 100 }
      }));

      const transRows = [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Waktu", bold: true })] })] }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Tipe", bold: true })] })] }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keterangan", bold: true })] })] }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Jumlah", bold: true })], alignment: AlignmentType.RIGHT })] }),
          ]
        })
      ];

      [...(h.incomes || []), ...(h.expenses || [])].sort((a: any, b: any) => new Date(a.time).getTime() - new Date(b.time).getTime()).forEach((t: any) => {
        const isIncome = (h.incomes || []).includes(t);
        transRows.push(new TableRow({
          children: [
            new TableCell({ children: [new Paragraph(new Date(t.time).toLocaleTimeString())] }),
            new TableCell({ children: [new Paragraph(isIncome ? "MASUK" : "KELUAR")] }),
            new TableCell({ children: [new Paragraph(t.note || (isIncome ? "Penjualan" : "Biaya"))] }),
            new TableCell({ children: [new Paragraph({ text: formatCurrency(t.amount), alignment: AlignmentType.RIGHT })] }),
          ]
        }));
        if (t.items && t.items.length > 0) {
          t.items.forEach((item: any) => {
            transRows.push(new TableRow({
              children: [
                new TableCell({ children: [new Paragraph("")] }),
                new TableCell({ children: [new Paragraph("")] }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: `   > ${item.name} (${item.quantity}x @ ${formatCurrency(item.price)})`, italics: true })] })] }),
                new TableCell({ children: [new Paragraph("")] }),
              ]
            }));
          });
        }
      });

      sections.push(new Table({
        width: { size: 95, type: WidthType.PERCENTAGE },
        rows: transRows
      }));
    });

    // Signatures
    sections.push(new Paragraph({ text: "", spacing: { before: 800 } }));
    sections.push(new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: { top: { style: "none" }, bottom: { style: "none" }, left: { style: "none" }, right: { style: "none" }, insideHorizontal: { style: "none" }, insideVertical: { style: "none" } },
      rows: [
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Tanda Tangan Pengelola", bold: true })], alignment: AlignmentType.CENTER })] }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Tanda Tangan Saksi", bold: true })], alignment: AlignmentType.CENTER })] }),
          ]
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ text: "", spacing: { before: 1000 } })] }),
            new TableCell({ children: [new Paragraph({ text: "", spacing: { before: 1000 } })] }),
          ]
        }),
        new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ text: "( ........................................ )", alignment: AlignmentType.CENTER })] }),
            new TableCell({ children: [new Paragraph({ text: "( ........................................ )", alignment: AlignmentType.CENTER })] }),
          ]
        }),
      ]
    }));

    const doc = new Document({
      sections: [{
        properties: {},
        children: sections,
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Laporan_Premium_${new Date().getTime()}.docx`);
  };

  const exportToCSV = () => {
    const headers = ["Tanggal", "Modal Awal", "Penjualan", "Sisa Modal", "Biaya Keluar", "Kas Net"];
    const rows = filteredHistory.map((h: any) => [
      new Date(h.date).toLocaleDateString('id-ID'),
      h.capital || 0,
      h.sales || 0,
      h.incomesTotal || 0,
      h.expensesTotal || 0,
      h.netCash || 0
    ]);
    
    let csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n" 
      + rows.map(e => e.join(",")).join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Laporan_Keuangan_${new Date().getTime()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 p-6 md:p-10 overflow-y-auto space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
        <div>
          <h2 className="text-2xl font-black italic uppercase text-yellow-500 tracking-tighter">Arsip Rekapan Bisnis</h2>
          <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mt-1">Total {history.length} Laporan Tersimpan</p>
        </div>
        <div className="flex items-center gap-2">
          <button id="btn-export-word" onClick={exportToWord} className="flex items-center gap-3 bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-2xl text-[10px] font-black uppercase transition-all text-white active:scale-95 shadow-lg shadow-blue-600/20">
            <FileText size={18}/> Ekspor ke Word
          </button>
          <button id="btn-export-csv" onClick={exportToCSV} className="flex items-center gap-3 bg-green-600 hover:bg-green-700 px-8 py-4 rounded-2xl text-[10px] font-black uppercase transition-all text-white active:scale-95 shadow-lg shadow-green-600/20">
            <FileText size={18}/> Ekspor ke Sheets (CSV)
          </button>
          <button id="btn-export-pdf" onClick={exportToPDF} className="flex items-center gap-3 bg-yellow-500 hover:bg-yellow-600 px-8 py-4 rounded-2xl text-[10px] font-black uppercase transition-all text-black active:scale-95 shadow-lg shadow-yellow-500/20">
            <Download size={18}/> Download PDF
          </button>
          <button id="btn-print-report" onClick={() => window.print()} className="flex items-center gap-3 bg-white/5 hover:bg-white/10 px-8 py-4 rounded-2xl text-[10px] font-black uppercase transition-all border border-white/5 active:scale-95">
            <Printer size={18} className="text-yellow-500"/> Cetak Laporan
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-panel p-6 rounded-[32px] border-white/5 no-print">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">Dari Tanggal</label>
            <input 
              type="date" 
              value={startDate} 
              onChange={e => setStartDate(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-[10px] font-bold outline-none focus:border-yellow-500 text-white"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">Sampai Tanggal</label>
            <input 
              type="date" 
              value={endDate} 
              onChange={e => setEndDate(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-[10px] font-bold outline-none focus:border-yellow-500 text-white"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">Filter Produk</label>
            <select 
              value={filterProduct} 
              onChange={e => setFilterProduct(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-[10px] font-bold outline-none focus:border-yellow-500 text-white appearance-none"
            >
              <option value="">SEMUA PRODUK</option>
              {allProducts.map((p, i) => <option key={i} value={p}>{p}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">Cari Transaksi</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" size={12} />
              <input 
                type="text" 
                placeholder="NAMA BARANG / CATATAN..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-xl py-3 pl-9 pr-3 text-[10px] font-bold outline-none focus:border-yellow-500 text-white uppercase"
              />
            </div>
          </div>
          <div className="flex items-end">
            <button 
              onClick={() => { setStartDate(''); setEndDate(''); setFilterProduct(''); setSearchQuery(''); }}
              className="w-full bg-red-500/10 text-red-500 border border-red-500/20 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-red-500/20 transition-all"
            >
              Reset Filter
            </button>
          </div>
        </div>
      </div>

      {/* Visualisasi Analitik Terpadu */}
      {filteredHistory.length > 0 && (
        <div className="no-print">
          <div className="glass-panel p-8 rounded-[48px] border-white/5 flex flex-col h-[500px] mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-yellow-500">
                  <TrendingUp size={24}/>
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-widest">Analisis Keuangan Terpadu</h3>
                  <p className="text-[8px] text-gray-500 font-bold uppercase tracking-widest">Tren Penjualan, Biaya, dan Kas Net</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-[8px] font-black text-gray-400 uppercase">Penjualan</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-[8px] font-black text-gray-400 uppercase">Biaya Keluar</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-[8px] font-black text-gray-400 uppercase">Kas Net</span>
                </div>
              </div>
            </div>
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#4b5563', fontSize: 8, fontWeight: 900}} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#4b5563', fontSize: 8, fontWeight: 900}}
                    tickFormatter={(value) => value >= 1000000 ? `${(value/1000000).toFixed(1)}M` : value >= 1000 ? `${(value/1000).toFixed(0)}K` : value}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    verticalAlign="top" 
                    align="right" 
                    iconType="circle"
                    wrapperStyle={{ paddingBottom: '20px', fontSize: '8px', fontWeight: '900', textTransform: 'uppercase' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="sales" 
                    name="Penjualan" 
                    stroke="#22c55e" 
                    strokeWidth={3} 
                    dot={{ r: 4, fill: '#22c55e', strokeWidth: 2, stroke: '#080808' }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="expenses" 
                    name="Biaya Keluar" 
                    stroke="#ef4444" 
                    strokeWidth={3} 
                    dot={{ r: 4, fill: '#ef4444', strokeWidth: 2, stroke: '#080808' }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="profit" 
                    name="Kas Net" 
                    stroke="#3b82f6" 
                    strokeWidth={3} 
                    dot={{ r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: '#080808' }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="glass-panel p-8 rounded-[48px] border-white/5 flex flex-col h-[500px] mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-yellow-500">
                  <TrendingUp size={24}/>
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-widest">Tren Bulanan</h3>
                  <p className="text-[8px] text-gray-500 font-bold uppercase tracking-widest">Akumulasi Penjualan, Biaya, dan Kas Net</p>
                </div>
              </div>
            </div>
            <div className="flex-1 min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#4b5563', fontSize: 8, fontWeight: 900}} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#4b5563', fontSize: 8, fontWeight: 900}}
                    tickFormatter={(value) => value >= 1000000 ? `${(value/1000000).toFixed(1)}M` : value >= 1000 ? `${(value/1000).toFixed(0)}K` : value}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{fill: '#ffffff05'}} />
                  <Legend 
                    verticalAlign="top" 
                    align="right" 
                    iconType="circle"
                    wrapperStyle={{ paddingBottom: '20px', fontSize: '8px', fontWeight: '900', textTransform: 'uppercase' }}
                  />
                  <Bar dataKey="sales" name="Penjualan" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expenses" name="Biaya Keluar" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="profit" name="Kas Net" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Tabel Arsip Layar */}
      <div className="glass-panel rounded-[48px] overflow-hidden no-print border-white/5">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-black/50 text-[9px] font-black text-gray-500 uppercase border-b border-white/5">
                <th className="p-8">Tanggal Tutup Buku</th>
                <th className="p-8 text-right">Modal Awal</th>
                <th className="p-8 text-right">Penjualan</th>
                {features.showIncome && <th className="p-8 text-right">Sisa Modal</th>}
                <th className="p-8 text-right">Biaya Out</th>
                <th className="p-8 text-right">Kas Net</th>
              </tr>
            </thead>
            <tbody className="text-[10px] text-gray-300">
              {filteredHistory.map((h: any, i: number) => (
                <tr key={i} className="border-b border-white/5 hover:bg-yellow-500/5 transition-all group">
                  <td className="p-8 font-mono text-gray-500 group-hover:text-white transition-colors">{new Date(h.date).toLocaleString('id-ID')}</td>
                  <td className="p-8 text-right text-gray-400">{formatCurrency(h.capital || 0)}</td>
                  <td className="p-8 text-right text-green-500 font-bold">{formatCurrency(h.sales)}</td>
                  {features.showIncome && <td className="p-8 text-right text-blue-500">{formatCurrency(h.incomesTotal || 0)}</td>}
                  <td className="p-8 text-right text-red-500">{formatCurrency(h.expensesTotal)}</td>
                  <td className="p-8 text-right text-yellow-500 italic font-black text-xs">{formatCurrency(h.netCash)}</td>
                </tr>
              ))}
              {filteredHistory.length > 0 && (
                <tr className="bg-white/5 border-t border-white/10 font-black text-white">
                  <td className="p-8 uppercase tracking-widest text-yellow-500">Total Keseluruhan</td>
                  <td className="p-8 text-right text-gray-400">{formatCurrency(totals.capital)}</td>
                  <td className="p-8 text-right text-green-500">{formatCurrency(totals.sales)}</td>
                  {features.showIncome && <td className="p-8 text-right text-blue-500">{formatCurrency(totals.incomes)}</td>}
                  <td className="p-8 text-right text-red-500">{formatCurrency(totals.expenses)}</td>
                  <td className="p-8 text-right text-yellow-500 text-xs">{formatCurrency(totals.netCash)}</td>
                </tr>
              )}
              {filteredHistory.length === 0 && (
                <tr><td colSpan={features.showIncome ? 6 : 5} className="p-20 text-center text-gray-700 font-black uppercase tracking-widest opacity-20">Tidak ada data sesuai filter</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Layout Cetak Laporan Besar */}
      <div className="print-only hidden p-10 text-black">
          <div className="text-center mb-8 border-b-2 border-black pb-4">
            <h1 className="text-3xl font-black uppercase tracking-tighter">{storeName}</h1>
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] mt-2">Laporan Keuangan Bisnis Premium</p>
          </div>
          
          <div className="mb-8 flex justify-between items-end text-[10px] font-bold uppercase">
             <div>
               <p className="text-gray-500 mb-1">Periode Laporan</p>
               <p>{startDate || 'Awal'} s/d {endDate || 'Sekarang'}</p>
             </div>
             <div className="text-right">
               <p className="text-gray-500 mb-1">Dicetak Pada</p>
               <p>{new Date().toLocaleString('id-ID')}</p>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Modal Awal</p>
              <p className="text-xl font-black">{formatCurrency(totals.capital)}</p>
            </div>
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Penjualan</p>
              <p className="text-xl font-black">{formatCurrency(totals.sales)}</p>
            </div>
            {features.showIncome && (
              <div className="border border-black p-4">
                <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Sisa Modal</p>
                <p className="text-xl font-black">{formatCurrency(totals.incomes)}</p>
              </div>
            )}
            <div className="border border-black p-4">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Pengeluaran</p>
              <p className="text-xl font-black">{formatCurrency(totals.expenses)}</p>
            </div>
            <div className="col-span-2 border border-black p-4 bg-gray-100">
              <p className="text-[8px] font-bold uppercase text-gray-500 mb-1">Total Kas Net (Saldo Akhir)</p>
              <p className="text-2xl font-black">{formatCurrency(totals.netCash)}</p>
            </div>
          </div>

          <h3 className="text-xs font-black uppercase mb-4 border-l-4 border-black pl-3">Rekapitulasi Harian</h3>
          <table className="w-full text-[9px] border-collapse mb-10">
              <thead>
                  <tr className="bg-gray-200 font-black uppercase border border-black">
                      <th className="p-2 border border-black text-left">Waktu Rekap</th>
                      <th className="p-2 border border-black text-right">Modal</th>
                      <th className="p-2 border border-black text-right">Penjualan</th>
                      {features.showIncome && <th className="p-2 border border-black text-right">Sisa Modal</th>}
                      <th className="p-2 border border-black text-right">Biaya Out</th>
                      <th className="p-2 border border-black text-right">Kas Net</th>
                  </tr>
              </thead>
              <tbody>
                  {filteredHistory.map((h: any, i: number) => (
                      <tr key={i} className="border border-black">
                          <td className="p-2 border border-black">{new Date(h.date).toLocaleString('id-ID')}</td>
                          <td className="p-2 border border-black text-right">{formatCurrency(h.capital || 0)}</td>
                          <td className="p-2 border border-black text-right">{formatCurrency(h.sales)}</td>
                          {features.showIncome && <td className="p-2 border border-black text-right">{formatCurrency(h.incomesTotal || 0)}</td>}
                          <td className="p-2 border border-black text-right">{formatCurrency(h.expensesTotal)}</td>
                          <td className="p-2 border border-black text-right font-bold">{formatCurrency(h.netCash)}</td>
                      </tr>
                  ))}
              </tbody>
          </table>

          <h3 className="text-xs font-black uppercase mb-4 border-l-4 border-black pl-3">Rincian Transaksi Per Nota</h3>
          <div className="space-y-6">
            {filteredHistory.map((h: any, i: number) => (
              <div key={i} className="border border-black p-4 break-inside-avoid">
                <p className="text-[10px] font-black uppercase mb-3 border-b border-black pb-1">Tanggal: {new Date(h.date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                <table className="w-full text-[8px] border-collapse">
                  <thead>
                    <tr className="font-bold border-b border-black">
                      <th className="text-left py-1">Waktu</th>
                      <th className="text-left py-1">Tipe</th>
                      <th className="text-left py-1">Keterangan / Item</th>
                      <th className="text-right py-1">Jumlah</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...(h.incomes || []), ...(h.expenses || [])].sort((a: any, b: any) => new Date(a.time).getTime() - new Date(b.time).getTime()).map((t: any, idx: number) => {
                      const isIncome = (h.incomes || []).includes(t);
                      return (
                        <React.Fragment key={idx}>
                          <tr className="border-b border-gray-100">
                            <td className="py-1">{new Date(t.time).toLocaleTimeString()}</td>
                            <td className="py-1 font-bold">{isIncome ? 'MASUK' : 'KELUAR'}</td>
                            <td className="py-1">{t.note || (isIncome ? "Penjualan" : "Biaya")}</td>
                            <td className="py-1 text-right">{formatCurrency(t.amount)}</td>
                          </tr>
                          {t.items && t.items.length > 0 && t.items.map((item: any, itemIdx: number) => (
                            <tr key={`${idx}-${itemIdx}`} className="text-gray-500 italic border-b border-gray-50 border-dotted">
                              <td></td>
                              <td></td>
                              <td className="py-0.5 pl-4">   {">"} {item.name} ({item.quantity}x @ {formatCurrency(item.price)})</td>
                              <td></td>
                            </tr>
                          ))}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ))}
          </div>

          <div className="mt-12 pt-8 border-t border-black flex justify-between items-start text-[8px] font-bold uppercase">
            <div>
              <p className="mb-10 text-gray-500">Tanda Tangan Pengelola</p>
              <p>( ........................................ )</p>
            </div>
            <div className="text-right">
              <p className="mb-10 text-gray-500">Tanda Tangan Saksi</p>
              <p>( ........................................ )</p>
            </div>
          </div>
          
          <div className="mt-10 text-center text-[7px] text-gray-400 font-bold uppercase tracking-widest">
            Laporan ini dihasilkan secara resmi oleh {storeName} - {officialLabel}
          </div>
      </div>
    </div>
  );
}

function AIModule({ developer, dailyStats, history, formatCurrency, aiModel, setAiModel }: any) {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    
    const currentInput = input.trim();
    const userMsg = { role: 'user', text: currentInput };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const historySummary = history.slice(0, 30).map((h: any) => ({
        date: h.date,
        sales: h.sales,
        expenses: h.expensesTotal,
        incomes: h.incomesTotal,
        net: h.netCash
      }));
      const context = `
        Kamu adalah MasdeenAI v2.0 (Powered by Multi-Claude Engine), asisten keuangan cerdas tingkat lanjut untuk toko "${developer}".
        
        DATA HARI INI:
        - Penjualan: ${formatCurrency(dailyStats.sales)}
        - Transaksi: ${dailyStats.transactions}
        - Pengeluaran: ${formatCurrency(dailyStats.expenses?.reduce((s: number, e: any) => s + e.amount, 0))}
        - Pemasukan Eksternal: ${formatCurrency(dailyStats.incomes?.reduce((s: number, i: any) => s + i.amount, 0))}
        
        DATA HISTORIS (30 Laporan Terakhir):
        ${JSON.stringify(historySummary)}

        TUGAS KHUSUS:
        1. Analisis Tren: Berikan wawasan mendalam tentang tren penjualan dan pengeluaran.
        2. Laporan Berkala: Jika diminta "LAPORAN MINGGUAN" atau "LAPORAN BULANAN", buat analisis komprehensif.
        3. Rekomendasi Strategis: Berikan saran konkret untuk meningkatkan keuntungan atau efisiensi biaya.
        4. Deteksi Anomali: Beritahu jika ada pengeluaran yang tidak biasa atau penurunan penjualan yang signifikan.
        5. Visualisasi Data: Gunakan tabel Markdown untuk menyajikan data yang kompleks.
        
        Gunakan format Markdown yang profesional. Jadilah asisten yang proaktif, cerdas, dan membantu.
        Saat ini kamu menggunakan engine: ${aiModel === 'gemini-3.1-pro-preview' ? 'High-Reasoning Pro Mode (Claude-Class)' : 'Ultra-Fast Flash Mode'}.
        
        PENTING: Jangan pernah memberikan saran investasi atau keuangan yang berisiko tinggi. Fokus pada operasional toko.
      `;

      // Limit history to last 15 messages for better context
      const recentMessages = messages.slice(-15);

      const response = await ai.models.generateContent({
        model: aiModel,
        contents: [
          ...recentMessages.map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] })), 
          { role: 'user', parts: [{ text: currentInput }] }
        ],
        config: {
          systemInstruction: context,
          temperature: 0.7,
        }
      });

      const aiMsg = { 
        role: 'model', 
        text: response.text || 'Maaf, saya tidak bisa memproses permintaan Anda saat ini.',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', text: 'Terjadi kesalahan saat menghubungi AI. Pastikan API Key Anda valid.', timestamp: new Date().toISOString() }]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => setMessages([]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Teks berhasil disalin ke papan klip!");
  };

  const generateReport = (type: 'WEEKLY' | 'MONTHLY') => {
    const prompt = type === 'WEEKLY' 
      ? "Tolong buatkan LAPORAN MINGGUAN berdasarkan data 7 laporan terakhir saya."
      : "Tolong buatkan LAPORAN BULANAN berdasarkan data 30 laporan terakhir saya.";
    setInput(prompt);
    setTimeout(() => {
      const btn = document.getElementById('btn-send-ai');
      btn?.click();
    }, 100);
  };

  return (
    <div className="flex-1 flex flex-col p-6 md:p-10 overflow-hidden">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(234,179,8,0.3)] relative overflow-hidden group">
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            <BrainCircuit size={28} className="relative z-10"/>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white uppercase tracking-tighter">MasdeenAI v2.0</h2>
              <span className="px-2 py-0.5 bg-yellow-500/10 text-yellow-500 text-[8px] font-black rounded border border-yellow-500/20 uppercase tracking-widest">Premium</span>
            </div>
            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest flex items-center gap-2">
              <Zap size={10} className="text-yellow-500"/> Multi-Claude Engine Connected
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          <div className="flex bg-black/50 p-1 rounded-xl border border-white/10 shadow-inner">
            <button 
              onClick={() => setAiModel('gemini-3-flash-preview')}
              className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${aiModel === 'gemini-3-flash-preview' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-gray-500 hover:text-white'}`}
            >
              Flash Mode
            </button>
            <button 
              onClick={() => setAiModel('gemini-3.1-pro-preview')}
              className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${aiModel === 'gemini-3.1-pro-preview' ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/20' : 'text-gray-500 hover:text-white'}`}
            >
              Pro Mode (Claude)
            </button>
          </div>
          
          <div className="h-8 w-[1px] bg-white/5 hidden lg:block"></div>

          <div className="flex items-center gap-2">
            <button onClick={() => generateReport('WEEKLY')} className="px-4 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-500 rounded-xl text-[9px] font-black uppercase tracking-widest border border-blue-500/20 transition-all">
              Laporan Mingguan
            </button>
            <button onClick={() => generateReport('MONTHLY')} className="px-4 py-2 bg-green-500/10 hover:bg-green-500/20 text-green-500 rounded-xl text-[9px] font-black uppercase tracking-widest border border-green-500/20 transition-all">
              Laporan Bulanan
            </button>
            <button onClick={clearChat} className="p-2 bg-white/5 hover:bg-white/10 rounded-xl text-gray-500 hover:text-red-500 transition-all border border-white/5">
              <Trash2 size={16}/>
            </button>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 mb-6 pr-2">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
            <BrainCircuit size={64} className="text-yellow-500"/>
            <p className="text-[10px] font-black uppercase tracking-widest max-w-xs">Halo! Saya MasdeenAI. Tanyakan apa saja tentang performa bisnis Anda hari ini.</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`relative group max-w-[85%] p-5 rounded-3xl text-[11px] font-medium leading-relaxed ${m.role === 'user' ? 'bg-yellow-500 text-black font-bold shadow-lg shadow-yellow-500/10' : 'bg-[#0a0a0a] text-gray-300 border border-white/10 shadow-2xl'}`}>
              {m.role === 'model' && (
                <button 
                  onClick={() => copyToClipboard(m.text)}
                  className="absolute -top-2 -right-2 p-2 bg-black border border-white/10 rounded-lg text-gray-500 hover:text-yellow-500 opacity-0 group-hover:opacity-100 transition-all shadow-xl"
                  title="Salin Teks"
                >
                  <Share2 size={12}/>
                </button>
              )}
              <div className="markdown-body prose prose-invert prose-xs max-w-none">
                <Markdown>{m.text}</Markdown>
              </div>
              <div className={`mt-3 text-[8px] font-black uppercase tracking-widest ${m.role === 'user' ? 'text-black/40' : 'text-gray-600'}`}>
                {m.role === 'user' ? 'Anda' : 'MasdeenAI'} • {new Date(m.timestamp || new Date()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-[#0a0a0a] p-5 rounded-3xl border border-white/10 flex items-center gap-3 shadow-2xl">
              <div className="relative">
                <div className="w-4 h-4 border-2 border-yellow-500/20 border-t-yellow-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 bg-yellow-500/20 blur-sm animate-pulse rounded-full"></div>
              </div>
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest animate-pulse">
                {aiModel === 'gemini-3.1-pro-preview' ? 'Menganalisis dengan Pro Engine...' : 'Berpikir...'}
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="relative">
        <input 
          id="ai-input"
          type="text" 
          value={input} 
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="TANYA MASDEENAI..."
          className="w-full bg-[#080808] border border-white/10 rounded-2xl py-5 pl-6 pr-16 text-xs font-bold outline-none focus:border-yellow-500 uppercase transition-all"
        />
        <button id="btn-send-ai" onClick={handleSend} className="absolute right-4 top-1/2 -translate-y-1/2 text-yellow-500 hover:scale-110 transition-transform">
          <Send size={20}/>
        </button>
      </div>
    </div>
  );
}

function SettingsModule({ storeName, setStoreName, receiptHeader, setReceiptHeader, receiptFooter, setReceiptFooter, receiptLogo, setReceiptLogo, receiptColor, setReceiptColor, currency, setCurrency, developer, officialLabel, onResetData, posMode, setPosMode, features, setFeatures, onBackup, onRestore }: any) {
  return (
    <div className="flex-1 p-6 md:p-10 overflow-y-auto no-print">
      <div className="max-w-2xl mx-auto glass-panel p-12 rounded-[56px]">
        <h2 className="text-2xl font-black text-yellow-500 mb-10 uppercase border-b border-white/5 pb-8 italic tracking-tighter">Konfigurasi Sistem</h2>
        <div className="space-y-10">
          
          {/* Backup & Restore Section */}
          <div className="bg-blue-500/5 p-8 rounded-[40px] border border-blue-500/20">
            <label className="text-[11px] font-black text-blue-400 uppercase mb-6 block tracking-[0.2em]">Manajemen Data & Backup</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={onBackup}
                className="flex items-center justify-center gap-3 p-5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-600/20"
              >
                <Cloud size={20}/> Backup Data
              </button>
              <div className="relative">
                <input 
                  type="file" 
                  accept=".json" 
                  onChange={onRestore}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <button className="w-full flex items-center justify-center gap-3 p-5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-300 font-black uppercase tracking-widest transition-all border border-white/10">
                  <Download size={20}/> Restore Data
                </button>
              </div>
            </div>
            <p className="text-[9px] text-gray-500 mt-4 font-medium italic">Gunakan fitur ini untuk mencadangkan seluruh data Anda ke file lokal atau memulihkannya kembali.</p>
          </div>

          <div>
              <label className="text-[11px] font-black text-gray-500 uppercase mb-4 block tracking-[0.2em]">Identitas Nama Toko / Bisnis</label>
              <input id="input-store-name" type="text" value={storeName} onChange={e => setStoreName(e.target.value)} 
                className="w-full bg-black/50 border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-yellow-500 text-sm transition-all" />
          </div>

          <div className="bg-white/5 p-8 rounded-[40px] border border-white/10">
            <label className="text-[11px] font-black text-gray-500 uppercase mb-6 block tracking-[0.2em]">Fitur & Modul Aktif</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={() => setFeatures({...features, showSales: !features.showSales})}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${features.showSales ? 'bg-green-500/10 border-green-500/30 text-green-500' : 'bg-white/5 border-white/10 text-gray-500'}`}
              >
                <div className="flex items-center gap-3">
                  <ShoppingCart size={18}/>
                  <span className="text-[10px] font-black uppercase tracking-widest">Modul Penjualan</span>
                </div>
                <div className={`w-8 h-4 rounded-full relative transition-all ${features.showSales ? 'bg-green-500' : 'bg-gray-700'}`}>
                  <div className={`absolute top-1 w-2 h-2 bg-white rounded-full transition-all ${features.showSales ? 'right-1' : 'left-1'}`}></div>
                </div>
              </button>

              <button 
                onClick={() => setFeatures({...features, showIncome: !features.showIncome})}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${features.showIncome ? 'bg-blue-500/10 border-blue-500/30 text-blue-500' : 'bg-white/5 border-white/10 text-gray-500'}`}
              >
                <div className="flex items-center gap-3">
                  <PlusCircle size={18}/>
                  <span className="text-[10px] font-black uppercase tracking-widest">Fitur Kas Masuk</span>
                </div>
                <div className={`w-8 h-4 rounded-full relative transition-all ${features.showIncome ? 'bg-blue-500' : 'bg-gray-700'}`}>
                  <div className={`absolute top-1 w-2 h-2 bg-white rounded-full transition-all ${features.showIncome ? 'right-1' : 'left-1'}`}></div>
                </div>
              </button>

              <button 
                onClick={() => setFeatures({...features, showAIChat: !features.showAIChat})}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${features.showAIChat ? 'bg-purple-500/10 border-purple-500/30 text-purple-500' : 'bg-white/5 border-white/10 text-gray-500'}`}
              >
                <div className="flex items-center gap-3">
                  <BrainCircuit size={18}/>
                  <span className="text-[10px] font-black uppercase tracking-widest">Masdeen AI Chat</span>
                </div>
                <div className={`w-8 h-4 rounded-full relative transition-all ${features.showAIChat ? 'bg-purple-500' : 'bg-gray-700'}`}>
                  <div className={`absolute top-1 w-2 h-2 bg-white rounded-full transition-all ${features.showAIChat ? 'right-1' : 'left-1'}`}></div>
                </div>
              </button>

              <button 
                onClick={() => setFeatures({...features, showCustomerModule: !features.showCustomerModule})}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${features.showCustomerModule ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-500' : 'bg-white/5 border-white/10 text-gray-500'}`}
              >
                <div className="flex items-center gap-3">
                  <Users size={18}/>
                  <span className="text-[10px] font-black uppercase tracking-widest">Modul Pelanggan</span>
                </div>
                <div className={`w-8 h-4 rounded-full relative transition-all ${features.showCustomerModule ? 'bg-yellow-500' : 'bg-gray-700'}`}>
                  <div className={`absolute top-1 w-2 h-2 bg-white rounded-full transition-all ${features.showCustomerModule ? 'right-1' : 'left-1'}`}></div>
                </div>
              </button>
            </div>
          </div>

          <div className="bg-white/5 p-8 rounded-[40px] border border-white/10">
            <label className="text-[11px] font-black text-gray-500 uppercase mb-6 block tracking-[0.2em]">Mode Transaksi POS</label>
            <div className="flex bg-black p-1.5 rounded-2xl border border-white/10 shadow-inner">
              <button 
                onClick={() => setPosMode('JUAL')} 
                className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-xl text-[10px] font-black uppercase transition-all ${posMode === 'JUAL' ? 'bg-green-600 text-white shadow-lg shadow-green-600/20' : 'text-gray-500 hover:text-white'}`}
              >
                <ShoppingCart size={18}/> Mode Jual (Retail)
              </button>
              <button 
                onClick={() => setPosMode('BELI')} 
                className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-xl text-[10px] font-black uppercase transition-all ${posMode === 'BELI' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-gray-500 hover:text-white'}`}
              >
                <ShoppingBag size={18}/> Mode Beli (Stok)
              </button>
            </div>
            <p className="text-[9px] text-gray-500 mt-4 font-medium italic">Pilih mode transaksi utama yang akan digunakan di layar kasir.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <label className="text-[11px] font-black text-gray-500 uppercase mb-4 block tracking-[0.2em]">Header Struk (Alamat/Kontak)</label>
                <textarea 
                  value={receiptHeader} 
                  onChange={e => setReceiptHeader(e.target.value)} 
                  rows={3}
                  className="w-full bg-black/50 border border-white/10 rounded-2xl p-5 text-white font-medium outline-none focus:border-yellow-500 text-xs transition-all resize-none" 
                />
            </div>
            <div>
                <label className="text-[11px] font-black text-gray-500 uppercase mb-4 block tracking-[0.2em]">Footer Struk (Pesan/Ketentuan)</label>
                <textarea 
                  value={receiptFooter} 
                  onChange={e => setReceiptFooter(e.target.value)} 
                  rows={3}
                  className="w-full bg-black/50 border border-white/10 rounded-2xl p-5 text-white font-medium outline-none focus:border-yellow-500 text-xs transition-all resize-none" 
                />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <label className="text-[11px] font-black text-gray-500 uppercase mb-4 block tracking-[0.2em]">Logo Struk (URL Gambar)</label>
                <input 
                  type="text"
                  placeholder="https://example.com/logo.png"
                  value={receiptLogo} 
                  onChange={e => setReceiptLogo(e.target.value)} 
                  className="w-full bg-black/50 border border-white/10 rounded-2xl p-5 text-white font-medium outline-none focus:border-yellow-500 text-xs transition-all" 
                />
            </div>
            <div>
                <label className="text-[11px] font-black text-gray-500 uppercase mb-4 block tracking-[0.2em]">Warna Aksen Struk (Hex)</label>
                <div className="flex items-center gap-4">
                  <input 
                    type="color"
                    value={receiptColor} 
                    onChange={e => setReceiptColor(e.target.value)} 
                    className="w-12 h-12 rounded-xl cursor-pointer bg-transparent border-0 p-0" 
                  />
                  <input 
                    type="text"
                    value={receiptColor} 
                    onChange={e => setReceiptColor(e.target.value)} 
                    className="flex-1 bg-black/50 border border-white/10 rounded-2xl p-5 text-white font-medium outline-none focus:border-yellow-500 text-xs transition-all uppercase" 
                  />
                </div>
            </div>
          </div>
          
          <div className="pt-10 border-t border-white/5 space-y-8">
              <div className="bg-red-500/5 p-8 rounded-[40px] border border-red-500/10">
                <div className="flex items-center gap-4 mb-4">
                  <AlertTriangle size={24} className="text-red-500"/>
                  <h4 className="text-[12px] font-black text-white uppercase tracking-widest">Zona Bahaya</h4>
                </div>
                <p className="text-[10px] text-gray-400 mb-6 font-medium">Menghapus seluruh data transaksi, produk, dan pelanggan. Tindakan ini tidak dapat dibatalkan.</p>
                <button 
                  onClick={onResetData}
                  className="px-6 py-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-widest transition-all border border-red-500/20 flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  Reset Seluruh Data
                </button>
              </div>

              <div className="bg-blue-500/10 p-8 rounded-[40px] border border-blue-500/20 flex items-start gap-6">
                <BadgeCheck size={32} className="text-blue-500 shrink-0"/>
                <div>
                    <h4 className="text-[12px] font-black text-white uppercase mb-2 tracking-widest">{officialLabel}</h4>
                    <p className="text-[10px] text-gray-400 leading-relaxed font-medium">Sistem ini dilindungi dan disahkan sepenuhnya oleh <strong>{developer}</strong>. Segala bentuk salinan cetak secara otomatis menyertakan tanda pengesahan ini.</p>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}
